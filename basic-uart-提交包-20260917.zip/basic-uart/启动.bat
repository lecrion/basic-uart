@echo off
rem ---------------------------------------------------------------
rem  UART assistant launcher (double-click to run).
rem  Keep this file ASCII-only: non-ASCII text after "chcp" makes
rem  cmd.exe mis-parse the rest of the batch file.
rem ---------------------------------------------------------------
setlocal
cd /d "%~dp0"

set "PY="
if exist ".venv\Scripts\python.exe" set "PY=.venv\Scripts\python.exe"
if not defined PY set "PY=python"

"%PY%" -c "import PyQt5, serial, pyqtgraph" 1>nul 2>nul
if errorlevel 1 goto nodeps

echo Launching UART assistant...
"%PY%" uart_assistant.py
if errorlevel 1 goto failed
goto done

:nodeps
echo.
echo [ERROR] Python or dependencies not available.
echo.
echo Interpreter tried: %PY%
echo Install the dependencies first:
echo     %PY% -m pip install -r requirements.txt
echo.
pause
goto done

:failed
echo.
echo [ERROR] The program exited with an error. Read the message above.
echo.
pause

:done
endlocal
