# basic-uart · 串口调试助手

> 「鹰眼计划」本科生科创任务 · 雷达上位机监控软件编写《两周入门作业》
>
> 两周目标：**开发一个可运行的"串口调试助手"**。
> 本仓库是该工具的实现，也是后续雷达遥测 / 调试软件的最小起点。

任务书原文（验收标准就是按这两张图逐条对照的）：

![任务书 1](Images/task_detail_1.jpg)

![任务书 2](Images/task_detail_2.jpg)

一个用 Python 写的串口调试助手：底层用 `pyserial` 封装成可复用的核心库，
上层用 `PyQt5` 搭界面、`pyqtgraph` 画实时曲线。
**内置虚拟串口，没有接任何硬件也能完整演示和自测。**

---

## 1. 效果预览

接收窗口（带毫秒时间戳，正在接收模拟雷达遥测帧）：

![接收窗口](Images/screenshot_receive.png)

数据绘图页（实时解析 `$RADAR` 遥测帧并画曲线）：

![数据绘图](Images/screenshot_plot.png)

小挑战演示：连接串口 → 发送 `Hello` → 收到回显 → HEX 显示：

![小挑战](Images/screenshot_hello_hex.png)

---

## 2. 快速开始

> **只拿到一个压缩包、想先跑起来** → 看 [`安装教程.md`](安装教程.md)，
> 从解压讲到看见界面，含环境要求与常见错误对照表。
>
> **已经跑起来了、想知道怎么用** → 看 [`docs/运行教程.md`](docs/运行教程.md)。

### 2.1 安装依赖

```bash
python -m venv .venv                       # 可选，但推荐
.venv\Scripts\activate                     # Windows
# source .venv/bin/activate                # Linux / macOS

pip install -r requirements.txt
```

`requirements.txt` 里只有三个包：

| 包 | 用途 |
|---|---|
| pyserial | 串口底层收发 |
| PyQt5 | 图形界面 |
| pyqtgraph | 实时曲线绘图 |

只想用命令行版本的话，装 `pyserial` 就够了。

### 2.2 运行

```bash
python uart_assistant.py
```

Windows 上也可以直接**双击仓库根目录的 `启动.bat`**：它会自动找到解释器
（优先项目目录里的 `.venv`，找不到就退回 PATH 里的 python），
检查依赖是否装好，再启动界面。依赖缺失时会给出提示并停住，不会一闪而过。

> 注意：这个 .bat 必须保持纯 ASCII 内容。里面一旦出现中文，再配合 `chcp` 改代码页，
> cmd.exe 会从错误的字节偏移继续解析批处理，后面的命令全部失效 —— 界面就再也起不来了。

**没有任何硬件也能跑**：端口下拉里有两个内置虚拟串口，直接选它就能演示。

| 虚拟端口 | 行为 |
|---|---|
| `VIRTUAL:ECHO` | 回环设备：发什么就原样收回来（等价于把 TX/RX 短接） |
| `VIRTUAL:RADAR` | 模拟雷达遥测源：按帧率持续输出 `$RADAR` 数据帧，并接受命令 |

`VIRTUAL:RADAR` 支持三条在线命令，直接在发送框里发即可：

| 命令 | 作用 |
|---|---|
| `HELLO` | 回一条 `$RADAR,ACK,HELLO`（小挑战用） |
| `RATE=50` | 把帧率改成 50 帧/秒 |
| `NOISE=0.8` | 把噪声强度改成 0.8（0～1），曲线上立刻能看出差别 |
| `STATUS` | 查询当前帧率、噪声、已发帧数 |

一键演示（自动连上模拟雷达）：

```bash
python uart_assistant.py --demo
```

### 2.3 接真实硬件

把 USB 转串口模块插上，点界面里的 **刷新**，下拉框里就会出现 `COM3` 之类的真实端口；
选端口 → 选波特率 → 点 **打开串口** 即可。

先确认硬件通不通：

```bash
python tools/serial_smoke_test.py --list
python tools/serial_smoke_test.py -p COM3 -r 115200 --send "Hello" --expect "Hello"
```

---

## 3. 界面功能对照验收单

验收单要求"软件界面必须能完成"的五项，以及作业里要求的其余能力：

| 要求 | 在本工具里的位置 |
|---|---|
| **选择端口** | 左上「端口」下拉框 + 「刷新」按钮（真实串口与虚拟串口一并列出） |
| **连接状态显示** | 「打开/关闭串口」按钮下方的圆点 + 文字（未连接 / 已连接 VIRTUAL:RADAR），并在状态栏显示日志路径 |
| **发送框** | 底部「发送」输入框，`Ctrl+Enter` 发送 |
| **接收窗口** | 右侧「接收窗口」页，只读、等宽字体、自动滚动 |
| **清空窗口** | 工具栏「清空窗口」按钮（`Ctrl+L`） |
| 接收数据带时间戳 | 每行前缀 `[时:分:秒.毫秒]`，可用「显示时间戳」关掉 |
| 扫描串口 / 选择波特率 | 端口下拉 + 可编辑的波特率下拉（9600 ~ 921600） |
| 数据位 / 校验位 / 停止位 / 流控 | 左侧「串口设置」面板，全部可选 |
| 十六进制显示（小挑战加分项） | 工具栏「HEX 显示」，可在 ASCII / HEX 之间随时切换并重绘历史 |
| 接收内容保存为 txt（小挑战加分项） | 工具栏「保存接收为 txt」 |
| 循环发送 | 底部「循环发送」+ 间隔（ms） |
| 在线改参数 | 串口打开状态下直接改波特率，立即生效 |
| 曲线显示 | 「数据绘图」页，实时画距离 / 速度 / 信噪比 |

---

## 4. 小挑战：连接 → 发送 Hello → 收到 → 断开

现场按这四步做，一步都不用接硬件：

1. 「端口」选 `VIRTUAL:ECHO`，「波特率」保持 `115200`，点 **打开串口** —— 状态变成 `● 已连接 VIRTUAL:ECHO`；
2. 发送框输入 `Hello`，点 **发送**（或按 `Ctrl+Enter`）；
3. 接收窗口立刻出现一行 `[23:49:31.568] Hello` —— 这就是回环设备把数据原样发回来了；
4. 点 **关闭串口**，状态回到 `● 未连接`。

加的两个小功能（验收单里"增加一个小功能，十六进制显示或保存为 txt"，两个都做了）：

* 勾上 **HEX 显示**，刚才那行会变成 `48 65 6C 6C 6F`；
* 点 **保存接收为 txt**，接收窗口的内容会存成 .txt 文件。

---

## 5. 改一个参数再比较（验收单「重点提高」项）

### 对比一：波特率如何决定吞吐量

UART 每传 1 个字节要占 10 bit（8N1：1 起始位 + 8 数据位 + 1 停止位），
所以 **链路每秒能传的字节数 = 波特率 ÷ 10**。

对着 `VIRTUAL:RADAR` 连续请求 50 帧/秒（每帧 37 字节），换不同波特率接收：

| 波特率(bit/s) | 链路速率(B/s) | 理论上限(帧/s) | 实收帧数 | 送达率(%) | 收尾积压(B) |
|---|---|---|---|---|---|
| 9600 | 960 | 25.9 | 89 | 59.3 | 2241 |
| 19200 | 1920 | 51.9 | 148 | 98.7 | 42 |
| 38400 | 3840 | 103.8 | 150 | 100.0 | 37 |
| 115200 | 11520 | 311.4 | 149 | 99.3 | 37 |

9600 下链路只能带 25.9 帧/秒，而请求是 50 帧/秒，多出来的数据**堵在接收缓冲区里**，
采集结束时还有 2.2 KB 没送到（约等于比设备实际进度落后 2.3 秒）。
如果缓冲区被写满，后面的数据就会被直接丢掉。

**结论：波特率是串口链路的硬上限**，采集雷达这类连续数据时，必须按数据率反推着选。

复现：

```bash
python tools/baud_experiment.py
```

也可以手工做：连上 `VIRTUAL:RADAR` → 发 `RATE=50` → 在左侧把波特率从 `115200` 改成 `9600`
（运行中即时生效）→ 观察接收窗口里帧序号推进的速度明显变慢。

### 对比二：噪声参数如何影响信噪比

在运行中发 `NOISE=0.05` 和 `NOISE=0.8`，接收到的 `snr` 字段统计：

| NOISE | snr 均值(dB) | snr 标准差 | 范围 |
|---|---|---|---|
| 0.05 | 21.10 | 0.93 | [18.5, 22.9] |
| 0.80 | 10.72 | 1.09 | [8.0, 12.7] |

在「数据绘图」页能直接看到：噪声一大，绿色信噪比曲线整体下移并且毛刺变多。

完整数据见 [`docs/参数对比结果.md`](docs/参数对比结果.md)。

---

## 6. 项目结构

```
basic-uart/
├── uart_assistant.py          # 图形界面主程序（主要成果）
├── uart_cli.py                # 命令行版本，支持 stdin/stdout 管道收发
├── requirements.txt
├── uart_core/                 # 核心库：把 pyserial 封装成可复用模块
│   ├── __init__.py
│   ├── channel.py             # SerialChannel：单串口收发 / 回调 / 双向日志
│   ├── manager.py             # ChannelManager：同时管理多个串口
│   ├── ports.py               # 串口枚举（真实 + 虚拟）
│   ├── logbook.py             # 带时间戳的收发日志
│   ├── protocols.py           # HEX/ASCII 格式化、按行分帧、遥测帧解析
│   ├── virtual.py             # 内置虚拟串口与模拟设备
│   └── qtplugin.py            # 规避 Qt5 在中文路径下无法启动的问题
├── tools/
│   ├── selfcheck.py           # 一键自检（20 项，不需要硬件）
│   ├── baud_experiment.py     # 参数对比实验，自动生成结果表与对比图
│   ├── make_screenshots.py    # 重新生成 README 里的截图
│   ├── serial_smoke_test.py   # 真实硬件冒烟测试
│   └── qt_smoke_test.py       # PyQt 环境自检
├── docs/
│   ├── 运行教程.md             # 从零开始怎么装、怎么打开、报错怎么查
│   ├── 一页说明.md             # 提交要求里的"一页说明"
│   ├── 演示脚本.md             # 5 分钟现场演示流程 + 讲解词
│   ├── 提交清单.md             # 验收检查单逐项对照
│   └── 参数对比结果.md / .csv / .png
└── Images/                    # 运行截图与参考图
```

---

## 7. 核心库用法

核心库不依赖 Qt，可以单独 import 当子模块用：

```python
from uart_core import SerialChannel, parse_radar_frame

with SerialChannel("VIRTUAL:RADAR", baudrate=115200, log_dir="log") as channel:
    # 用装饰器注册"接收中断"处理函数，标签名随便起
    @channel.register_recv_trigger("打印")
    def on_data(data: bytes) -> None:
        frame = parse_radar_frame(data)
        if frame:
            print(frame)

    channel.send("RATE=10\r\n")        # 发命令
    channel.reconfigure(baudrate=9600) # 运行中改参数
    channel.start_cyclic_send(b"PING\r\n", interval=1.0)  # 循环发送
```

主要能力：

| 能力 | 接口 |
|---|---|
| 多串口同时打开、互不干扰 | `ChannelManager.open_channel(port, **params)` |
| 任意命名的接收回调（模拟串口接收中断） | `register_recv_trigger(tag)` / `add_recv_callback(func, tag)` |
| 接收过滤器 | `add_recv_filter(func)`，返回 `None` 即丢弃该批数据 |
| 循环发送 | `start_cyclic_send(payload, interval)` / `stop_cyclic_send()` |
| 运行时改波特率 / 校验位 / 数据位 / 停止位 / 流控 | `reconfigure(**params)` |
| 每个串口收发双向日志 | 构造时传 `log_dir=`，日志在 `log/<端口>/session_<时间>.log` |
| 优雅关闭（停线程、关端口、可重复调用） | `close()`，或直接用 `with` 语句 |
| 串口异常断开自动上报 | `add_error_callback(func)` / `add_state_callback(func)` |

---

## 8. 命令行用法

```bash
python uart_cli.py --list                          # 列出所有端口
python uart_cli.py -p VIRTUAL:RADAR                # 交互式收发（输入 :q 退出）
python uart_cli.py -p VIRTUAL:ECHO --send "Hello" --duration 2
python uart_cli.py -p VIRTUAL:RADAR --hex          # 以十六进制显示
echo "HELLO" | python uart_cli.py -p VIRTUAL:RADAR --stdin   # 管道模式
```

`--stdin` / 管道模式就是 README 技术设想里要求的
"作为单独的程序调用，通过 stdin/stdout 进行数据的出入"。

---

## 9. 自检

不需要任何硬件，一条命令验证全部功能：

```bash
python tools/selfcheck.py
```

会依次检查核心库（收发、回调异常隔离、多通道隔离、过滤、循环发送、在线改参数、日志、
优雅关闭）、界面（五项界面能力、带时间戳收发、HEX 切换、保存 txt、绘图）和链路限速行为，
共 20 项，失败时退出码为 1。

---

## 10. 关于原始版本

本仓库第一版（提交历史里的 `serial_io_core.py`）已经跑通了 pyserial 的基本收发，
但存在若干会影响演示的问题，本版做了对应修复：

| 原始版本的问题 | 本版做法 |
|---|---|
| `_serial_dict` / `_trigger_list` 写成了类属性，多串口实际共享同一张表 | 全部改为实例属性，多通道真正隔离 |
| 只认写死的 `test_1` / `test_2` 两个标签，自定义标签直接 `KeyError` | 标签可自由命名，注册的回调全部生效 |
| `_trigger_test_2` 定义了但接收循环从不调用 | 所有标签的回调都会被调用 |
| 回调抛异常会打死接收线程，之后永久收不到数据 | 回调异常被捕获并上报，接收循环继续运行 |
| `remove_serial_io()` 调用了不存在的方法，抛 `AttributeError` | `close_channel()` 真正停线程、关端口并移除条目 |
| 接收线程不是守护线程且无人 join，进程无法退出 | 线程为守护线程，`close()` 会 join，可重复调用 |
| 先关管道再关串口，线程写已关闭的管道抛 `ValueError` | 先停线程再释放资源，顺序正确 |
| 只记录接收方向，日志没有时间戳 | 收发双向、带毫秒时间戳 |
| 依赖 Windows 专属的 `CREATE_NEW_CONSOLE` 和相对路径 | 改为进程内分发，跨平台 |
| 没有界面，只有 14 行的 PyQt 弹窗测试 | 完整的 PyQt5 界面 + pyqtgraph 曲线 |

原有的 `serial_test.py` 和 `interface_test.py` 分别整理成了
`tools/serial_smoke_test.py` 和 `tools/qt_smoke_test.py`，仍然可以单独使用。

> 本节提到的 `serial_io_core.py`、`serial_test.py`、`interface_test.py`、
> `serial_recv_display.py`、`serial_recv_display_utf8.py` 都已在本次重构中移除，
> 需要查阅请翻 git 历史（`git show 321241b:serial_io_core.py`）。

---

## 11. 与「鹰眼计划」/ SAR 系统的关系

这个工具本身不做雷达信号处理，它是**后续雷达遥测与调试软件的最小起点**：

* 串口是雷达分系统与上位机之间最常见的数据通道，本工具封装并验证了这条通道；
* 「接收窗口 + 时间戳 + 十六进制」正是排查遥测帧格式、帧头帧尾、校验错误时最常用的手段；
* 「数据绘图」页演示了遥测数据从字节流 → 解析 → 曲线的完整链路，
  雷达的 SAR 成像结果、脉冲压缩波形、信噪比曲线后续都可以接到同一套框架上；
* 第 5 节的波特率对比实验说明了一个雷达工程里的实际问题：
  **数据率决定链路选型**，采样率一提高，9600 的串口立刻就不够用了。
