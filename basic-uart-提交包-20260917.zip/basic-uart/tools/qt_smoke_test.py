"""PyQt 环境自检：确认 PyQt5 装好了、能弹出窗口。

这是原来 ``interface_test.py`` 的内容，保留下来当作"环境装好了吗"的第一步检查。
装完依赖后先跑它，再跑 ``uart_assistant.py``。

    python tools/qt_smoke_test.py
"""

from __future__ import annotations

import os
import sys

try:
    import PyQt5
    from PyQt5 import QtCore, QtWidgets
except ImportError as exc:
    print(f"没有找到 PyQt5: {exc}")
    print("请先安装依赖: pip install -r requirements.txt")
    raise SystemExit(1) from exc

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from uart_core.qtplugin import ensure_qt_plugin_path  # noqa: E402

ensure_qt_plugin_path()


def main() -> int:
    app = QtWidgets.QApplication(sys.argv[:1])
    window = QtWidgets.QMainWindow()
    window.setWindowTitle("PyQt5 环境自检 · 关闭窗口即通过")
    window.setGeometry(200, 200, 460, 220)

    label = QtWidgets.QLabel(
        "PyQt5 工作正常。\n\n"
        f"PyQt5 版本: {QtCore.PYQT_VERSION_STR}\n"
        f"Qt 版本: {QtCore.QT_VERSION_STR}\n"
        f"Python: {sys.version.split()[0]}\n\n"
        "关掉这个窗口后请运行: python uart_assistant.py"
    )
    label.setAlignment(QtCore.Qt.AlignCenter)
    window.setCentralWidget(label)
    window.show()
    return app.exec_()


if __name__ == "__main__":
    sys.exit(main())
