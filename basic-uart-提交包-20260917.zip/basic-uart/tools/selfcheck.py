"""项目自检：不需要任何硬件，跑一遍就知道代码是否正常。

    python tools/selfcheck.py

覆盖三块：
    核心库  —— 收发、回调、过滤、循环发送、在线改参数、日志、优雅关闭
    界面    —— 离屏启动 PyQt5 界面，验证验收单要求的五项界面能力
    实验    —— 链路按波特率限速的行为是否符合预期

任一检查失败时退出码为 1，便于在提交前确认"能不能跑"。
"""

from __future__ import annotations

import os
import sys
import threading
import time
import traceback

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)


def _force_utf8_stdout() -> None:
    """重定向到文件时用 UTF-8 输出（Windows 控制台默认 GBK 会把中文写成乱码）。"""
    for stream in (sys.stdout, sys.stderr):
        try:
            if stream.isatty():
                stream.reconfigure(errors="replace")
            else:
                stream.reconfigure(encoding="utf-8", errors="replace")
        except Exception:  # noqa: BLE001 - 不是所有流都支持 reconfigure
            pass


_force_utf8_stdout()

# 界面部分必须离屏运行，服务器/无显示器环境同样可用
os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

import uart_core  # noqa: E402
from uart_core.qtplugin import ensure_qt_plugin_path  # noqa: E402

ensure_qt_plugin_path()
from uart_core import (  # noqa: E402
    ChannelError,
    ChannelManager,
    LineAssembler,
    RadarSeries,
    SerialChannel,
    format_ascii,
    format_hex,
    list_ports,
    parse_hex,
    parse_radar_frame,
    save_text,
)

LOG_DIR = os.path.join(ROOT, "log", "selfcheck")

CHECKS: list[tuple[str, callable]] = []


def check(name: str):
    def decorator(func):
        CHECKS.append((name, func))
        return func

    return decorator


def wait_for(predicate, timeout: float = 3.0, interval: float = 0.02) -> bool:
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        if predicate():
            return True
        time.sleep(interval)
    return predicate()


# =============================================================== 工具层
@check("工具: HEX 与 ASCII 格式化")
def _tool_format():
    assert format_hex(b"\x00\x0f\xff") == "00 0F FF"
    assert parse_hex("48 65 6C") == b"Hel"
    assert parse_hex("0x48,0x65") == b"He"
    assert parse_hex("48656C6C6F") == b"Hello"
    try:
        parse_hex("48 6")
    except ValueError:
        pass
    else:
        raise AssertionError("奇数长度的 HEX 应该报错")
    # 关键：非 UTF-8 字节不能抛异常（旧版就是在这里打死接收线程的）
    assert "\\xff" in format_ascii(b"\xff\xfe")
    assert format_ascii(b"hi\r\n") == "hi\\r\\n"
    return "format_hex / parse_hex / format_ascii 均正常，非 UTF-8 字节不会抛异常"


@check("工具: 按行分帧")
def _tool_line_assembler():
    asm = LineAssembler(max_gap=0.05)
    assert asm.feed(b"AB") == []
    lines = asm.feed(b"C\r\n")
    assert [c for _, c in lines] == [b"ABC\r\n"], lines
    lines = asm.feed(b"one\r\ntwo\r\n")
    assert [c for _, c in lines] == [b"one\r\n", b"two\r\n"], lines
    assert asm.flush() == []
    asm.feed(b"tail")
    assert [c for _, c in asm.flush()] == [b"tail"]
    return "半行、多行、残留数据都能正确切分"


@check("工具: 遥测帧解析")
def _tool_frame_parse():
    frame = parse_radar_frame(b"$RADAR,000123,  128.40,   -3.20, 21.5\n")
    assert frame == {"seq": 123, "range": 128.4, "vel": -3.2, "snr": 21.5}, frame
    assert parse_radar_frame(b"$RADAR,ACK,HELLO,seq=7") is None
    assert parse_radar_frame(b"just text") is None
    series = RadarSeries()
    series.add({"seq": 1, "range": 1.0, "vel": 0.0, "snr": 10.0})
    series.add({"seq": 3, "range": 2.0, "vel": 0.0, "snr": 11.0})
    assert series.gaps == 1, series.gaps
    return "帧解析与丢帧统计正常"


# =============================================================== 核心库
@check("枚举: 真实串口与虚拟串口统一列出")
def _core_ports():
    ports = list_ports()
    devices = [info.device for info in ports]
    assert "VIRTUAL:ECHO" in devices and "VIRTUAL:RADAR" in devices, devices
    assert all(info.label for info in ports)
    assert uart_core.format_table(ports)
    return f"共 {len(ports)} 个端口，其中虚拟端口 {sum(1 for p in ports if p.is_virtual)} 个"


@check("收发: 虚拟回环设备一问一答")
def _core_echo():
    with ChannelManager(log_dir=LOG_DIR) as manager:
        channel = manager.open_channel("VIRTUAL:ECHO", baudrate=115200)
        got: list[bytes] = []
        channel.register_recv_trigger("test_echo")(got.append)
        channel.send(b"Hello\r\n")
        assert wait_for(lambda: got), "没有收到回环数据"
        assert b"Hello" in b"".join(got)
        snapshot = channel.snapshot()
        assert snapshot["bytes_tx"] == 7 and snapshot["bytes_rx"] == 7, snapshot
        return f"发出 7 字节并原样收回，收/发计数 {snapshot['bytes_rx']}/{snapshot['bytes_tx']}"


@check("回调: 任意标签名都可以注册（旧版只认 test_1/test_2）")
def _core_any_tag():
    with ChannelManager(log_dir=LOG_DIR) as manager:
        channel = manager.open_channel("VIRTUAL:ECHO")
        hits = {"a": 0, "b": 0}
        channel.register_recv_trigger("我自己的过滤器")(lambda d: hits.__setitem__("a", hits["a"] + 1))
        channel.register_recv_trigger("another-tag")(lambda d: hits.__setitem__("b", hits["b"] + 1))
        channel.send(b"x")
        assert wait_for(lambda: hits["a"] and hits["b"]), hits
        assert sorted(channel.callback_tags) == sorted(["我自己的过滤器", "another-tag"])
        return "自定义标签全部生效，旧版这里会抛 KeyError"


@check("回调: 抛异常不会打死接收线程（旧版会永久丢数据）")
def _core_callback_error():
    with ChannelManager(log_dir=LOG_DIR) as manager:
        channel = manager.open_channel("VIRTUAL:ECHO")
        seen: list[bytes] = []
        errors: list[str] = []

        def bad(data: bytes) -> None:
            data.decode("utf-8")  # 遇到任意非 UTF-8 字节就抛 UnicodeDecodeError

        channel.register_recv_trigger("bad")(bad)
        channel.register_recv_trigger("good")(seen.append)
        channel.add_error_callback(lambda exc, ctx: errors.append(ctx))
        channel.send(b"\xff\xfe not utf8")
        assert wait_for(lambda: seen), "坏回调之后数据就再也没有到达"
        channel.send(b"still alive")
        assert wait_for(lambda: len(seen) >= 2), seen
        assert channel.is_open, "接收线程不应该退出"
        assert errors, "错误回调没有被触发"
        return f"坏帧之后仍收到 {len(seen)} 批数据，错误已上报: {errors[0]}"


@check("隔离: 多个串口互不干扰（旧版用了类属性，全局共享）")
def _core_isolation():
    m1 = ChannelManager(log_dir=LOG_DIR)
    m2 = ChannelManager(log_dir=LOG_DIR)
    try:
        a = m1.open_channel("VIRTUAL:ECHO")
        b = m2.open_channel("VIRTUAL:ECHO")
        assert a is not b, "两个管理器不应该共用同一个通道对象"
        hits_a: list[bytes] = []
        hits_b: list[bytes] = []
        a.register_recv_trigger("only-a")(hits_a.append)
        b.register_recv_trigger("only-b")(hits_b.append)
        assert a.callback_tags == ["only-a"], a.callback_tags
        assert b.callback_tags == ["only-b"], b.callback_tags
        a.send(b"AAA")
        assert wait_for(lambda: hits_a)
        time.sleep(0.2)
        assert not hits_b, "B 通道收到了发给 A 的数据，说明触发列表被共享了"
        assert m1.ports() == ["VIRTUAL:ECHO"] and m2.ports() == ["VIRTUAL:ECHO"]
        return "两个管理器各自持有独立通道与独立回调表"
    finally:
        m1.close_all()
        m2.close_all()


@check("关闭: close / 移除通道真的会关端口并停线程（旧版抛 AttributeError）")
def _core_close():
    manager = ChannelManager(log_dir=LOG_DIR)
    channel = manager.open_channel("VIRTUAL:ECHO")
    assert channel.is_open
    assert manager.close_channel("VIRTUAL:ECHO") is True
    assert not channel.is_open, "关闭后 is_open 应为 False"
    assert manager.get("VIRTUAL:ECHO") is None, "通道没有被移出管理器"
    assert manager.close_channel("不存在的端口") is False, "关闭不存在的通道应返回 False"
    channel.close()  # 重复关闭必须安全
    channel.close()
    leftover = [t.name for t in threading.enumerate() if t.name.startswith(("uart-", "virtual-"))]
    assert wait_for(lambda: not [t for t in threading.enumerate() if t.name.startswith(("uart-", "virtual-"))]), leftover
    try:
        channel.send(b"x")
    except ChannelError:
        pass
    else:
        raise AssertionError("关闭后发送应该报 ChannelError")
    return "关闭后端口释放、线程退出、管理器条目移除，重复关闭安全"


@check("过滤器: 按批过滤接收数据")
def _core_filter():
    with ChannelManager(log_dir=LOG_DIR) as manager:
        channel = manager.open_channel("VIRTUAL:ECHO")
        kept: list[bytes] = []
        channel.add_recv_filter(lambda d: None if b"DROP" in d else d.upper())
        channel.register_recv_trigger("k")(kept.append)
        channel.send(b"keep")
        assert wait_for(lambda: kept == [b"KEEP"]), kept
        channel.send(b"DROP")
        time.sleep(0.25)
        assert kept == [b"KEEP"], kept
        return "未命中丢弃条件的批次照常上报，命中的被丢掉"


@check("循环发送: 按间隔自动重发并可停止")
def _core_cyclic():
    with ChannelManager(log_dir=LOG_DIR) as manager:
        channel = manager.open_channel("VIRTUAL:ECHO")
        got: list[bytes] = []
        channel.register_recv_trigger("c")(got.append)
        channel.start_cyclic_send(b"tick\n", interval=0.08)
        assert wait_for(lambda: len(got) >= 3, timeout=3.0), got
        assert channel.cyclic_active
        channel.stop_cyclic_send()
        assert not channel.cyclic_active
        count = len(got)
        time.sleep(0.3)
        assert len(got) <= count + 1, f"停止后仍在发送: {count} -> {len(got)}"
        return f"循环发送期间收到 {count} 次，停止后不再增长"


@check("在线改参数: 运行中修改波特率立即生效")
def _core_reconfigure():
    with ChannelManager(log_dir=LOG_DIR) as manager:
        channel = manager.open_channel("VIRTUAL:RADAR", baudrate=115200)
        assert channel.baudrate == 115200
        applied = channel.reconfigure(baudrate=9600)
        assert applied["baudrate"] == 9600 and channel.baudrate == 9600, applied
        assert channel._transport.stats()["bytes_per_second"] == 960.0
        try:
            channel.reconfigure(不存在的参数=1)
        except ValueError:
            pass
        else:
            raise AssertionError("未知参数应该报 ValueError")
        return "运行中把 115200 改为 9600 成功，链路速率同步变为 960 B/s"


@check("日志: 收发双向都写带时间戳的记录")
def _core_logging():
    with ChannelManager(log_dir=LOG_DIR) as manager:
        channel = manager.open_channel("VIRTUAL:ECHO")
        channel.send(b"logged-out")
        assert wait_for(lambda: channel.bytes_rx > 0)
        path = channel.log_path
        assert path and os.path.exists(path), path
    with open(path, encoding="utf-8") as handle:
        content = handle.read()
    assert "[TX]" in content and "[RX]" in content, content[:400]
    assert "logged-out" in content
    import re

    assert re.search(r"\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}\.\d{3} \[RX\]", content), content[:400]
    return f"日志含 [RX]/[TX] 与毫秒时间戳: {os.path.basename(path)}"


@check("模拟设备: 遥测帧 + 在线命令")
def _core_radar_device():
    with ChannelManager(log_dir=LOG_DIR) as manager:
        channel = manager.open_channel("VIRTUAL:RADAR", baudrate=115200)
        raw: list[bytes] = []
        channel.register_recv_trigger("raw")(raw.append)
        channel.send("RATE=40\r\n")
        channel.send("HELLO\r\n")
        assert wait_for(lambda: b"ACK,HELLO" in b"".join(raw), timeout=3.0)
        assert wait_for(
            lambda: len([1 for line in b"".join(raw).split(b"\n") if parse_radar_frame(line)]) >= 3,
            timeout=3.0,
        )
        blob = b"".join(raw)
        assert b"ACK,RATE=40" in blob, blob[:300]
        frames = [parse_radar_frame(line) for line in blob.split(b"\n")]
        frames = [f for f in frames if f]
        channel.send("NOISE=0.9\r\n")
        assert wait_for(lambda: b"ACK,NOISE=0.9" in b"".join(raw), timeout=2.0)
        return f"收到 {len(frames)} 帧遥测 + HELLO/RATE/NOISE 三条命令回执"


@check("限速: 波特率越低吞吐量越低（参数对比实验的基础）")
def _core_bandwidth():
    results = {}
    for baudrate in (9600, 115200):
        with ChannelManager(log_dir=None) as manager:
            channel = manager.open_channel("VIRTUAL:RADAR", baudrate=baudrate)
            raw: list[bytes] = []
            channel.register_recv_trigger("raw")(raw.append)
            channel.send("RATE=100\n")
            time.sleep(1.0)
            blob = b"".join(raw)
            results[baudrate] = len([1 for line in blob.split(b"\n") if parse_radar_frame(line)])
    assert results[9600] > 0, results
    assert results[115200] > results[9600], results
    return f"同样请求 100 帧/秒，实收 9600:{results[9600]} 帧 vs 115200:{results[115200]} 帧"


# =============================================================== 图形界面
def _gui():
    """延迟导入，避免核心库检查失败时连界面都起不来。"""
    import uart_assistant

    return uart_assistant


@check("界面: 五项必需的界面能力都在")
def _gui_widgets():
    from PyQt5 import QtWidgets

    ua = _gui()
    app, window = ua.build_app(["--log-dir", LOG_DIR])
    try:
        required = {
            "选择端口": window.port_combo,
            "连接状态显示": window.state_label,
            "发送框": window.send_edit,
            "接收窗口": window.recv_view,
            "清空窗口": window.clear_button,
        }
        for name, widget in required.items():
            assert isinstance(widget, QtWidgets.QWidget), f"{name} 不是控件"
        assert window.port_combo.count() >= 2, "端口下拉里应该有内置虚拟串口"
        assert window.state_label.text() == "未连接"
        assert window.clear_button.text() == "清空窗口"
        return "端口下拉 / 状态显示 / 发送框 / 接收窗口 / 清空按钮 全部就位"
    finally:
        window.close()


@check("界面: 打开串口 -> 发送 -> 带时间戳接收 -> 清空")
def _gui_roundtrip():
    import re

    ua = _gui()
    app, window = ua.build_app(["--log-dir", LOG_DIR])
    try:
        app.processEvents()
        index = window.port_combo.findData("VIRTUAL:ECHO")
        window.port_combo.setCurrentIndex(index)
        window.open_port()
        app.processEvents()
        assert window.state_label.text().startswith("已连接"), window.state_label.text()
        assert window.connect_button.text() == "关闭串口"

        window.send_edit.setPlainText("Hello")
        window.send_once()
        deadline = time.monotonic() + 3.0
        while time.monotonic() < deadline and "Hello" not in window.recv_view.toPlainText():
            app.processEvents()
            time.sleep(0.02)
        window._flush_pending()
        text = window.recv_view.toPlainText()
        assert "Hello" in text, text
        assert re.search(r"\[\d{2}:\d{2}:\d{2}\.\d{3}\]", text), f"接收内容没有时间戳: {text!r}"

        window.clear_receive()
        app.processEvents()
        assert window.recv_view.toPlainText() == "", "清空窗口没有生效"
        assert window.channel.snapshot()["bytes_tx"] == 7
        return f"收发成功且带时间戳: {text.strip()!r}；清空后窗口为空"
    finally:
        window.close()


@check("界面: HEX 显示切换与保存 txt")
def _gui_hex_and_save():
    from PyQt5 import QtWidgets

    ua = _gui()
    app, window = ua.build_app(["--log-dir", LOG_DIR])
    try:
        index = window.port_combo.findData("VIRTUAL:ECHO")
        window.port_combo.setCurrentIndex(index)
        window.open_port()
        window.send_edit.setPlainText("Hi")
        window.send_once()
        deadline = time.monotonic() + 3.0
        while time.monotonic() < deadline and "Hi" not in window.recv_view.toPlainText():
            app.processEvents()
            time.sleep(0.02)
        window._flush_pending()

        window.hex_view_check.setChecked(True)
        app.processEvents()
        hexed = window.recv_view.toPlainText()
        assert "48 69" in hexed, hexed            # "Hi" 的十六进制
        window.hex_view_check.setChecked(False)
        app.processEvents()
        assert "Hi" in window.recv_view.toPlainText()

        target = os.path.join(LOG_DIR, "saved_recv.txt")
        if os.path.exists(target):
            os.remove(target)
        original = QtWidgets.QFileDialog.getSaveFileName
        QtWidgets.QFileDialog.getSaveFileName = staticmethod(lambda *a, **k: (target, "txt"))
        try:
            window.save_receive()
        finally:
            QtWidgets.QFileDialog.getSaveFileName = original
        assert os.path.exists(target), "保存 txt 没有生成文件"
        with open(target, encoding="utf-8") as handle:
            saved = handle.read()
        assert "Hi" in saved
        return f"HEX 切换正常；接收内容已保存到 {os.path.basename(target)}（{len(saved)} 字符）"
    finally:
        window.close()


@check("界面: 遥测绘图与在线改波特率")
def _gui_plot():
    ua = _gui()
    app, window = ua.build_app(["--log-dir", LOG_DIR])
    try:
        index = window.port_combo.findData("VIRTUAL:RADAR")
        window.port_combo.setCurrentIndex(index)
        window.open_port()
        deadline = time.monotonic() + 3.0
        while time.monotonic() < deadline and window._series.frames < 5:
            app.processEvents()
            time.sleep(0.02)
        window._refresh_plot(force=True)
        assert window._series.frames >= 5, f"绘图没有收到遥测帧: {window._series.frames}"
        if window.plot_curves:
            xs, ys = window.plot_curves["range"].getData()
            assert len(xs) == len(ys) > 0, "曲线没有数据"
            assert window.plot_stats.text().startswith("帧 ")

        window.baud_combo.setCurrentText("9600")
        app.processEvents()
        assert window.channel.baudrate == 9600, window.channel.baudrate
        assert "9600" in window.info_label.text()
        return f"绘图累积 {window._series.frames} 帧；运行中把波特率改成 9600 并即时生效"
    finally:
        window.close()


@check("界面: 关闭后不残留后台线程")
def _gui_shutdown():
    ua = _gui()
    app, window = ua.build_app(["--log-dir", LOG_DIR])
    index = window.port_combo.findData("VIRTUAL:RADAR")
    window.port_combo.setCurrentIndex(index)
    window.open_port()
    app.processEvents()
    window.close()
    app.processEvents()
    assert not [t for t in threading.enumerate() if t.name.startswith(("uart-", "virtual-"))], (
        [t.name for t in threading.enumerate()]
    )
    return "窗口关闭后串口线程与虚拟设备线程都已退出"


def main() -> int:
    print("=" * 78)
    print("串口调试助手 · 自检")
    print("=" * 78)
    passed = failed = 0
    failures: list[tuple[str, str]] = []
    for name, func in CHECKS:
        start = time.monotonic()
        try:
            detail = func()
            passed += 1
            mark = "PASS"
        except Exception as exc:  # noqa: BLE001
            failed += 1
            mark = "FAIL"
            detail = f"{type(exc).__name__}: {exc}"
            failures.append((name, traceback.format_exc()))
        cost = (time.monotonic() - start) * 1000
        print(f"[{mark}] {name}  ({cost:.0f} ms)")
        print(f"       {detail}")
    print("-" * 78)
    print(f"共 {passed + failed} 项，通过 {passed} 项，失败 {failed} 项")
    if failures:
        print("\n失败详情:")
        for name, tb in failures:
            print(f"\n--- {name} ---\n{tb}")
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main())
