"""真实串口硬件冒烟测试（需要插着硬件，或用虚拟串口驱动配对）。

原来的 ``serial_test.py`` 直接调用 pyserial，不方便复用；这里改成走 ``uart_core``，
顺便验证真实硬件上的收发、参数显示是否正常。

    python tools/serial_smoke_test.py --list
    python tools/serial_smoke_test.py -p COM3 -r 115200
    python tools/serial_smoke_test.py -p COM3 -r 115200 --send "Hello" --expect "Hello"
"""

from __future__ import annotations

import argparse
import os
import sys
import time

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)

from uart_core import ChannelError, SerialChannel, format_hex, format_table, list_real_ports  # noqa: E402


def _utf8_stdout() -> None:
    for stream in (sys.stdout, sys.stderr):
        try:
            if stream.isatty():
                stream.reconfigure(errors="replace")
            else:
                stream.reconfigure(encoding="utf-8", errors="replace")
        except Exception:  # noqa: BLE001
            pass


def main() -> int:
    _utf8_stdout()
    parser = argparse.ArgumentParser(description="真实串口冒烟测试")
    parser.add_argument("--list", "-l", action="store_true", help="只列出真实串口")
    parser.add_argument("--port", "-p", help="要打开的端口，例如 COM3")
    parser.add_argument("--baudrate", "-r", type=int, default=115200)
    parser.add_argument("--send", "-s", default=None, help="打开后发送的内容")
    parser.add_argument("--expect", "-e", default=None, help="期望收到的子串（做回环测试时用）")
    parser.add_argument("--wait", "-w", type=float, default=1.5, help="等待接收的秒数，默认 1.5")
    parser.add_argument("--hex", action="store_true", help="以 HEX 打印接收内容")
    args = parser.parse_args()

    print("本机真实串口:")
    ports = list_real_ports()
    print(format_table(ports) if ports else "  （没有发现真实串口；请插上 USB 转串口设备）")
    if args.list or not args.port:
        if not args.port:
            print("\n提示: 用 -p 指定端口。没有硬件时请改用 uart_assistant.py 里的虚拟串口。")
        return 0

    try:
        channel = SerialChannel(args.port, log_dir=os.path.join(ROOT, "log"), baudrate=args.baudrate)
        channel.open()
    except ChannelError as exc:
        print(f"打开失败: {exc}", file=sys.stderr)
        return 2

    print(f"\n已打开 {channel.describe()}")
    print(f"  日志: {channel.log_path}")
    received: list[bytes] = []
    channel.add_recv_callback(received.append, tag="smoke")
    channel.add_error_callback(lambda exc, ctx: print(f"  !! {ctx}: {exc}", file=sys.stderr))

    try:
        if args.send:
            payload = args.send.encode("utf-8")
            print(f"发送 {len(payload)} 字节: {format_hex(payload)}")
            channel.send(payload)
        print(f"等待接收 {args.wait:g} 秒…")
        time.sleep(args.wait)
        blob = b"".join(received)
        print(f"收到 {channel.bytes_rx} 字节 / {len(received)} 批")
        if blob:
            print("  " + (format_hex(blob) if args.hex else blob.decode("utf-8", errors="backslashreplace")))
        else:
            print("  （没有收到任何数据；如果是在做回环测试，请确认 TX/RX 已短接或用对虚拟串口对）")

        if args.expect:
            if args.expect.encode("utf-8") in blob:
                print(f"回环校验通过: 收到了 {args.expect!r}")
                return 0
            print(f"回环校验失败: 没有收到 {args.expect!r}", file=sys.stderr)
            return 1
        return 0
    finally:
        channel.close()
        print(f"已关闭，本次会话收 {channel.bytes_rx} B / 发 {channel.bytes_tx} B")


if __name__ == "__main__":
    sys.exit(main())
