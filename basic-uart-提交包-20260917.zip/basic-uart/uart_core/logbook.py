"""带时间戳的收发日志。

旧版只在接收方向、且以裸字节追加写文件，既没有时间戳也没有发送记录。
这里每个串口一次会话一个日志文件，收发都记，并且附带 ASCII 与 HEX 两种转写，
方便事后核对，也满足 README 里"每个串口的输入/输出都保存到各自的日志"的设想。
"""

from __future__ import annotations

import datetime
import os
import threading

from .protocols import format_ascii, format_hex

__all__ = ["ChannelLog", "safe_name", "save_text"]

MAX_HEX_BYTES = 64


def safe_name(port: str) -> str:
    """把 `COM3` / `VIRTUAL:RADAR` 变成可以当目录名用的字符串。"""
    return "".join(ch if ch.isalnum() or ch in "-_." else "_" for ch in port)


def save_text(path: str, text: str) -> str:
    """把文本以 UTF-8 写入文件，返回绝对路径。"""
    directory = os.path.dirname(os.path.abspath(path))
    if directory:
        os.makedirs(directory, exist_ok=True)
    with open(path, "w", encoding="utf-8", newline="\n") as handle:
        handle.write(text)
    return os.path.abspath(path)


class ChannelLog:
    """单个串口一次会话的日志。线程安全，可以重复 close()。"""

    def __init__(self, log_dir: str, port: str, enabled: bool = True):
        self.log_dir = os.path.abspath(log_dir)
        self.port = port
        self.enabled = enabled
        self.path: str | None = None
        self._handle = None
        self._lock = threading.Lock()
        self.records = 0
        self.bytes_rx = 0
        self.bytes_tx = 0
        if not enabled:
            return

        folder = os.path.join(self.log_dir, safe_name(port))
        os.makedirs(folder, exist_ok=True)
        stamp = datetime.datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
        self.path = os.path.join(folder, f"session_{stamp}.log")
        self._handle = open(self.path, "w", encoding="utf-8", newline="\n")
        self.note(f"打开串口 {port}")

    # ------------------------------------------------------------------ 写入
    def _write(self, direction: str, data: bytes, size: int) -> None:
        if self._handle is None:
            return
        stamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]
        ascii_part = format_ascii(data)
        hex_part = format_hex(data[:MAX_HEX_BYTES])
        if len(data) > MAX_HEX_BYTES:
            hex_part += f" ... (+{len(data) - MAX_HEX_BYTES}B)"
        line = f'{stamp} [{direction}] {size:>6}B  ASCII: "{ascii_part}"  HEX: {hex_part}\n'
        with self._lock:
            if self._handle is None:
                return
            self._handle.write(line)
            self._handle.flush()
            self.records += 1

    def rx(self, data: bytes) -> None:
        self.bytes_rx += len(data)
        self._write("RX", data, len(data))

    def tx(self, data: bytes) -> None:
        self.bytes_tx += len(data)
        self._write("TX", data, len(data))

    def note(self, text: str) -> None:
        """记录一条说明（打开/关闭/参数变更等），不占用 RX/TX 计数。"""
        if self._handle is None:
            return
        stamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]
        with self._lock:
            if self._handle is None:
                return
            self._handle.write(f"{stamp} [--]        {text}\n")
            self._handle.flush()

    # ------------------------------------------------------------------ 收尾
    def close(self, note: str = "关闭串口") -> None:
        if self._handle is None:
            return
        self.note(note)
        with self._lock:
            handle, self._handle = self._handle, None
        handle.close()

    def __enter__(self) -> "ChannelLog":
        return self

    def __exit__(self, *exc_info) -> None:
        self.close()

    def summary(self) -> str:
        where = self.path or "(未启用)"
        return f"{self.port}: RX {self.bytes_rx}B / TX {self.bytes_tx}B / {self.records} 条记录 -> {where}"

    def __repr__(self) -> str:  # pragma: no cover - 便于调试
        state = "open" if self._handle is not None else "closed"
        return f"<ChannelLog {self.port} {state} {self.path}>"
