"""多串口管理。

旧版 ``SerialIOCore`` 把 ``_serial_dict`` 写成了类属性，于是两个内核实例共享同一张
串口表；``remove_serial_io()`` 还调用了一个根本不存在的方法。这里全部按实例状态实现，
并且 ``close_channel()`` 会真正停止线程、关闭端口。
"""

from __future__ import annotations

import threading

from .channel import SerialChannel

__all__ = ["ChannelManager"]


class ChannelManager:
    """管理若干个 :class:`SerialChannel`。

    ::

        manager = ChannelManager(log_dir="log")
        manager.open_channel("VIRTUAL:ECHO", baudrate=115200)
        manager.open_channel("VIRTUAL:RADAR", baudrate=9600)
        ...
        manager.close_all()
    """

    def __init__(self, log_dir: str | None = None):
        self.log_dir = log_dir
        self._channels: dict[str, SerialChannel] = {}
        self._lock = threading.RLock()

    # ------------------------------------------------------------------ 打开
    def open_channel(self, port: str, **settings) -> SerialChannel:
        """打开一个通道；同一个端口已经打开时直接返回原来的对象。"""
        with self._lock:
            existing = self._channels.get(port)
            if existing is not None and existing.is_open:
                return existing
            channel = SerialChannel(port, log_dir=self.log_dir, **settings)
            self._channels[port] = channel
        try:
            return channel.open()
        except Exception:
            with self._lock:
                if self._channels.get(port) is channel:
                    del self._channels[port]
            raise

    def add_channel(self, channel: SerialChannel) -> SerialChannel:
        """登记一个已经建好的通道（便于注入自定义 transport 做测试）。"""
        with self._lock:
            self._channels[channel.port] = channel
        return channel

    # ------------------------------------------------------------------ 查询
    def get(self, port: str) -> SerialChannel | None:
        with self._lock:
            return self._channels.get(port)

    def channels(self) -> list[SerialChannel]:
        with self._lock:
            return list(self._channels.values())

    def ports(self) -> list[str]:
        with self._lock:
            return list(self._channels)

    def open_ports(self) -> list[str]:
        return [ch.port for ch in self.channels() if ch.is_open]

    def summary(self) -> list[dict]:
        return [ch.snapshot() for ch in self.channels()]

    # ------------------------------------------------------------------ 关闭
    def close_channel(self, port: str, reason: str = "已关闭") -> bool:
        """关闭并移除一个通道，返回是否真的做了事。"""
        with self._lock:
            channel = self._channels.pop(port, None)
        if channel is None:
            return False
        channel.close(reason=reason)
        return True

    def close_all(self, reason: str = "全部关闭") -> int:
        with self._lock:
            channels = list(self._channels.values())
            self._channels.clear()
        for channel in channels:
            try:
                channel.close(reason=reason)
            except Exception:  # noqa: BLE001 - 收尾阶段不中断其它通道
                pass
        return len(channels)

    # ------------------------------------------------------------------ 杂项
    def __len__(self) -> int:
        with self._lock:
            return len(self._channels)

    def __contains__(self, port: object) -> bool:
        with self._lock:
            return port in self._channels

    def __iter__(self):
        return iter(self.channels())

    def __enter__(self) -> "ChannelManager":
        return self

    def __exit__(self, *exc_info) -> None:
        self.close_all(reason="上下文退出")

    def __repr__(self) -> str:  # pragma: no cover - 便于调试
        return f"<ChannelManager {len(self)} 个通道: {', '.join(self.ports()) or '空'}>"
