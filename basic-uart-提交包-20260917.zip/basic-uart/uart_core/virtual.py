"""不需要硬件的虚拟串口：程序内模拟收发。

验收说明里明确允许"可用虚拟串口或程序内模拟收发完成演示"，这里提供两个内置设备：

* ``VIRTUAL:ECHO``  —— 回环设备，收到什么原样发回（等价于把 TX/RX 短接），
  用来完成"连接串口 -> 发送 Hello -> 收到信息 -> 断开串口"的小挑战。
* ``VIRTUAL:RADAR`` —— 模拟雷达遥测源，周期性输出 ``$RADAR`` 数据帧，
  并接受 ``HELLO`` / ``RATE=`` / ``NOISE=`` 命令，用来现场"改一个参数再比较"。

链路按波特率限制吞吐量（8N1 下 1 字节 = 10 bit）。因此在 9600 下把发送速率调高，
缓冲区真的会积压并丢帧，界面上能看见序号跳跃 —— 这是可解释、可复现的对比实验。
"""

from __future__ import annotations

import math
import random
import threading
import time
from collections import deque

__all__ = [
    "VIRTUAL_PREFIX",
    "VIRTUAL_DEVICES",
    "is_virtual_port",
    "device_of",
    "open_virtual_transport",
    "VirtualLink",
    "VirtualSerial",
    "EchoDevice",
    "RadarDevice",
]

VIRTUAL_PREFIX = "VIRTUAL:"

#: 8N1 帧格式下每个字节占 10 bit（1 起始 + 8 数据 + 1 停止）
BITS_PER_BYTE = 10


class VirtualLink:
    """一条虚拟链路：两端各有一个接收缓冲，字节按波特率排队释放。"""

    def __init__(
        self,
        baudrate: int = 115200,
        latency: float = 0.004,
        max_buffer: int = 64 * 1024,
        chunk: int = 16,
    ):
        self._cond = threading.Condition()
        self._baudrate = int(baudrate)
        self._closed = False
        self.latency = float(latency)
        self.max_buffer = int(max_buffer)
        self.chunk = int(chunk)
        # 每个端点的待释放队列，元素为 [首字节可读时刻, 数据分片]
        self._buffers: dict[int, deque] = {0: deque(), 1: deque()}
        self.dropped_bytes = 0
        self.max_backlog = 0

    # ------------------------------------------------------------ 链路参数
    @property
    def baudrate(self) -> int:
        return self._baudrate

    @baudrate.setter
    def baudrate(self, value: int) -> None:
        with self._cond:
            self._baudrate = max(1, int(value))
            self._cond.notify_all()

    @property
    def bytes_per_second(self) -> float:
        return max(1.0, self._baudrate / BITS_PER_BYTE)

    @property
    def closed(self) -> bool:
        return self._closed

    # ------------------------------------------------------------ 数据搬运
    def write(self, sender: int, data: bytes) -> int:
        """``sender`` 端发出数据，进入对端缓冲并按波特率排队释放。"""
        if not data:
            return 0
        data = bytes(data)
        peer = 1 - sender
        now = time.monotonic()
        with self._cond:
            if self._closed:
                raise IOError("虚拟链路已关闭")
            queue = self._buffers[peer]
            cursor = queue[-1][0] if queue else now
            cursor = max(cursor, now + self.latency)
            for offset in range(0, len(data), self.chunk):
                piece = data[offset : offset + self.chunk]
                queue.append([cursor, piece])
                cursor += len(piece) / self.bytes_per_second

            total = sum(len(piece) for _, piece in queue)
            while total > self.max_buffer and len(queue) > 1:
                _, dropped = queue.popleft()
                total -= len(dropped)
                self.dropped_bytes += len(dropped)
            self.max_backlog = max(self.max_backlog, total)
            self._cond.notify_all()
        return len(data)

    def _available_in(self, queue: deque, now: float, limit: int | None = None) -> bytearray:
        """取出已经"传输完成"的字节。"""
        out = bytearray()
        bps = self.bytes_per_second
        while queue:
            release_at, piece = queue[0]
            if release_at > now:
                break
            done = int((now - release_at) * bps) + 1
            if done >= len(piece):
                out += piece
                queue.popleft()
            else:
                out += piece[:done]
                queue[0] = [release_at, piece[done:]]
                break
            if limit is not None and len(out) >= limit:
                break
        return out

    def take(self, endpoint: int, size: int, now: float | None = None) -> bytes:
        now = time.monotonic() if now is None else now
        with self._cond:
            return bytes(self._available_in(self._buffers[endpoint], now, size))

    def read(self, endpoint: int, size: int, timeout: float | None, now: float | None = None) -> bytes:
        """读取至多 ``size`` 字节；``timeout`` 秒内没有数据就返回空。"""
        deadline = None if timeout is None else (time.monotonic() if now is None else now) + timeout
        with self._cond:
            while True:
                data = self._available_in(self._buffers[endpoint], time.monotonic(), size)
                if data:
                    return bytes(data)
                if self._closed:
                    return b""
                if deadline is None:
                    self._cond.wait(0.05)
                    continue
                remaining = deadline - time.monotonic()
                if remaining <= 0:
                    return b""
                self._cond.wait(min(remaining, 0.05))

    def in_waiting(self, endpoint: int) -> int:
        now = time.monotonic()
        with self._cond:
            count = 0
            bps = self.bytes_per_second
            for release_at, piece in self._buffers[endpoint]:
                if release_at > now:
                    break
                count += min(len(piece), int((now - release_at) * bps) + 1)
            return count

    def backlog(self, endpoint: int) -> int:
        with self._cond:
            return sum(len(piece) for _, piece in self._buffers[endpoint])

    def close(self) -> None:
        with self._cond:
            self._closed = True
            self._cond.notify_all()

    def stats(self) -> dict:
        return {
            "baudrate": self._baudrate,
            "bytes_per_second": round(self.bytes_per_second, 1),
            "dropped_bytes": self.dropped_bytes,
            "max_backlog": self.max_backlog,
            "backlog": sum(self.backlog(end) for end in (0, 1)),
        }


class VirtualSerial:
    """pyserial ``Serial`` 的兼容外壳，够核心库使用即可。"""

    def __init__(
        self,
        link: VirtualLink,
        endpoint: int,
        port: str,
        bytesize: int = 8,
        parity: str = "N",
        stopbits: float = 1,
        timeout: float | None = 0.05,
        write_timeout: float | None = 1.0,
        xonxoff: bool = False,
        rtscts: bool = False,
        dsrdtr: bool = False,
    ):
        self._link = link
        self._endpoint = endpoint
        self.port = port
        self.bytesize = bytesize
        self.parity = parity
        self.stopbits = stopbits
        self.timeout = timeout
        self.write_timeout = write_timeout
        self.xonxoff = xonxoff
        self.rtscts = rtscts
        self.dsrdtr = dsrdtr
        self.is_open = False

    # baudrate 是链路级参数：改它等于改这一对虚拟串口之间的实际速率
    @property
    def baudrate(self) -> int:
        return self._link.baudrate

    @baudrate.setter
    def baudrate(self, value) -> None:
        self._link.baudrate = int(value)

    @property
    def in_waiting(self) -> int:
        return self._link.in_waiting(self._endpoint)

    def open(self) -> None:
        self.is_open = True

    def close(self) -> None:
        self.is_open = False

    def read(self, size: int = 1, timeout: float | None = None) -> bytes:
        return self._link.read(self._endpoint, size, self.timeout if timeout is None else timeout)

    def read_all(self) -> bytes:
        waiting = self._link.in_waiting(self._endpoint)
        if not waiting:
            return b""
        return self._link.read(self._endpoint, waiting, 0.0)

    def write(self, data: bytes) -> int:
        if not self.is_open:
            raise IOError(f"{self.port} 未打开")
        return self._link.write(self._endpoint, data)

    def flush(self) -> None:
        """真实串口这里会等待发送完成；虚拟链路用排队时间表达，无需额外动作。"""

    def reset_input_buffer(self) -> None:
        self._link.take(self._endpoint, 1 << 30)

    def reset_output_buffer(self) -> None:
        self._link.take(1 - self._endpoint, 1 << 30)

    def __repr__(self) -> str:  # pragma: no cover - 便于调试
        return f"<VirtualSerial {self.port} endpoint={self._endpoint}>"


# --------------------------------------------------------------------------- 设备
class VirtualDevice(threading.Thread):
    """虚拟设备线程基类：守护线程，关闭链路时会自行退出。

    注意：停止标志不能叫 ``_stop`` —— 那是 ``threading.Thread`` 的私有方法，
    覆盖掉之后 ``join()`` 会抛 ``'Event' object is not callable``。
    """

    description = "虚拟设备"

    def __init__(self, endpoint: VirtualSerial, name: str):
        super().__init__(name=f"virtual-device-{name}", daemon=True)
        self._endpoint = endpoint
        self._stop_event = threading.Event()

    def stop(self) -> None:
        self._stop_event.set()

    @property
    def stopped(self) -> bool:
        return self._stop_event.is_set()

    def read_available(self, timeout: float = 0.1) -> bytes:
        first = self._endpoint.read(1, timeout=timeout)
        if not first:
            return b""
        waiting = self._endpoint.in_waiting
        if waiting:
            first += self._endpoint.read(waiting, timeout=0.0)
        return first


class EchoDevice(VirtualDevice):
    """回环设备：收到什么就原样发回。"""

    description = "回环设备（收到什么原样发回，等价于短接 TX/RX）"

    def run(self) -> None:
        while not self._stop_event.is_set():
            data = self.read_available(timeout=0.1)
            if not data:
                continue
            try:
                self._endpoint.write(data)
            except Exception:  # noqa: BLE001 - 链路关闭即退出
                return


class RadarDevice(VirtualDevice):
    """模拟雷达遥测源。

    周期性输出 ``$RADAR,<seq>,<range>,<vel>,<snr>`` 文本帧，并接受三条下行命令：

    * ``HELLO``        -> 回一条 ``$RADAR,ACK,HELLO``（小挑战用）
    * ``RATE=<Hz>``    -> 修改帧率，比如 ``RATE=50``
    * ``NOISE=<0..1>`` -> 修改噪声强度，比如 ``NOISE=0.8``
    """

    description = "模拟雷达遥测源（周期输出 $RADAR 帧，支持 HELLO / RATE= / NOISE=）"

    def __init__(self, endpoint: VirtualSerial, name: str = "RADAR", rate_hz: float = 20.0, noise: float = 0.15):
        super().__init__(endpoint, name)
        self.rate_hz = float(rate_hz)
        self.noise = float(noise)
        self.seq = 0
        self.sent_frames = 0
        self.acks = 0
        self._random = random.Random(20260917)
        self._pending = bytearray()

    # -------------------------------------------------------------- 帧生成
    def make_frame(self) -> bytes:
        self.seq += 1
        scale = 0.5 + self.noise
        rng = 128.0 + 60.0 * math.sin(self.seq / 25.0) + self._random.gauss(0.0, 0.9 * scale)
        vel = 18.0 * math.cos(self.seq / 40.0) + self._random.gauss(0.0, 0.7 * scale)
        snr = 22.0 - 14.0 * self.noise + self._random.gauss(0.0, 1.0)
        return f"$RADAR,{self.seq:06d},{rng:8.2f},{vel:7.2f},{snr:5.1f}\n".encode()

    # -------------------------------------------------------------- 命令处理
    def _reply(self, text: str) -> None:
        self.acks += 1
        try:
            self._endpoint.write(text.encode() + b"\n")
        except Exception:  # noqa: BLE001
            pass

    def handle_command(self, line: str) -> None:
        command = line.strip()
        if not command:
            return
        upper = command.upper()
        if upper == "HELLO":
            self._reply(f"$RADAR,ACK,HELLO,seq={self.seq}")
        elif upper.startswith("RATE="):
            try:
                self.rate_hz = max(0.1, float(command.split("=", 1)[1]))
                self._reply(f"$RADAR,ACK,RATE={self.rate_hz:g}")
            except ValueError:
                self._reply("$RADAR,ERR,BAD_RATE")
        elif upper.startswith("NOISE="):
            try:
                self.noise = min(1.0, max(0.0, float(command.split("=", 1)[1])))
                self._reply(f"$RADAR,ACK,NOISE={self.noise:g}")
            except ValueError:
                self._reply("$RADAR,ERR,BAD_NOISE")
        elif upper == "STATUS":
            self._reply(
                f"$RADAR,STATUS,rate={self.rate_hz:g},noise={self.noise:g},sent={self.sent_frames}"
            )
        else:
            self._reply(f"$RADAR,ERR,UNKNOWN_CMD,{command}")

    def _drain_commands(self) -> None:
        data = self.read_available(timeout=0.0)
        if not data:
            return
        self._pending += data
        while True:
            index = self._pending.find(b"\n")
            if index < 0:
                break
            line = bytes(self._pending[:index])
            del self._pending[: index + 1]
            self.handle_command(line.decode("utf-8", errors="replace"))

    # -------------------------------------------------------------- 主循环
    def run(self) -> None:
        next_at = time.monotonic()
        while not self._stop_event.is_set():
            self._drain_commands()
            try:
                self._endpoint.write(self.make_frame())
            except Exception:  # noqa: BLE001 - 链路关闭即退出
                return
            self.sent_frames += 1
            next_at += 1.0 / max(self.rate_hz, 0.1)
            delay = next_at - time.monotonic()
            if delay < 0:  # 生成速度跟不上就重新对齐，不补发
                next_at = time.monotonic()
                delay = 0.0
            if self._stop_event.wait(delay):
                return


VIRTUAL_DEVICES: dict[str, type[VirtualDevice]] = {
    "ECHO": EchoDevice,
    "RADAR": RadarDevice,
}


# --------------------------------------------------------------------------- 工厂
def is_virtual_port(port: str) -> bool:
    return bool(port) and port.upper().startswith(VIRTUAL_PREFIX)


def device_of(port: str) -> str:
    return port[len(VIRTUAL_PREFIX) :].strip().upper()


class VirtualPortHandle:
    """把「链路 + 设备线程 + 应用端串口」打包成一个 pyserial 风格的句柄。"""

    #: 这些参数可以运行时修改，统一转发到应用端串口对象
    _FORWARDED = frozenset(
        {"bytesize", "parity", "stopbits", "timeout", "write_timeout", "xonxoff", "rtscts", "dsrdtr"}
    )

    def __init__(self, device_name: str, port: str, **params):
        device_cls = VIRTUAL_DEVICES.get(device_name)
        if device_cls is None:
            raise ValueError(
                f"未知虚拟设备 {device_name!r}，可选: {', '.join(sorted(VIRTUAL_DEVICES))}"
            )
        baudrate = int(params.pop("baudrate", 115200) or 115200)
        settings = self._clean(params)
        self.link = VirtualLink(baudrate=baudrate)
        self.port = port
        self.device_name = device_name
        self.is_open = False
        self.app = VirtualSerial(self.link, 0, port=port, **settings)
        self.dev = VirtualSerial(self.link, 1, port=f"{port}#device", **settings)
        self.device = device_cls(self.dev, device_name)

    @staticmethod
    def _clean(params: dict) -> dict:
        allowed = {"bytesize", "parity", "stopbits", "timeout", "write_timeout", "xonxoff", "rtscts", "dsrdtr"}
        return {k: v for k, v in params.items() if k in allowed}

    def __setattr__(self, name, value):
        # 运行时改参数要落到真正被读取的 app 端对象上
        if name in self._FORWARDED and "app" in self.__dict__:
            setattr(self.__dict__["app"], name, value)
            return
        object.__setattr__(self, name, value)

    def __getattr__(self, item):
        if item in ("app", "dev", "link", "device"):
            raise AttributeError(item)
        return getattr(self.__dict__["app"], item)

    # -------------------------------------------------------- pyserial 接口
    def open(self) -> None:
        self.app.open()
        self.dev.open()
        self.is_open = True
        if not self.device.is_alive():
            self.device.start()

    def close(self) -> None:
        self.is_open = False
        self.device.stop()
        self.link.close()
        self.app.close()
        self.dev.close()
        if self.device.is_alive():
            self.device.join(timeout=0.5)

    def read(self, size: int = 1) -> bytes:
        return self.app.read(size)

    def read_all(self) -> bytes:
        return self.app.read_all()

    def write(self, data: bytes) -> int:
        return self.app.write(data)

    def flush(self) -> None:
        self.app.flush()

    def reset_input_buffer(self) -> None:
        self.app.reset_input_buffer()

    def reset_output_buffer(self) -> None:
        self.app.reset_output_buffer()

    @property
    def in_waiting(self) -> int:
        return self.app.in_waiting

    # 运行时可改的参数，统一转发到应用端；baudrate 落在链路上
    @property
    def baudrate(self) -> int:
        return self.link.baudrate

    @baudrate.setter
    def baudrate(self, value) -> None:
        self.link.baudrate = int(value)

    def __getattr__(self, item):
        # 只兜底读取类属性（bytesize/parity/timeout/...），写入必须走上面的属性
        return getattr(self.app, item)

    def stats(self) -> dict:
        return self.link.stats()


def open_virtual_transport(port: str, **params) -> VirtualPortHandle:
    """按端口名创建虚拟串口。``port`` 形如 ``VIRTUAL:RADAR``。"""
    name = device_of(port)
    handle = VirtualPortHandle(name, port, **params)
    return handle
