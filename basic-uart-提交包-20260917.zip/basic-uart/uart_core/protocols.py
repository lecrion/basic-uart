"""纯函数工具层：HEX/ASCII 格式化、按行分帧、模拟遥测帧解析。

这一层不持有任何状态，也不依赖 pyserial/Qt，因此可以被 CLI、GUI 和自检脚本
共用，并且可以脱离硬件单独测试。
"""

from __future__ import annotations

import re
import time

__all__ = [
    "format_hex",
    "format_ascii",
    "parse_hex",
    "LineAssembler",
    "parse_radar_frame",
    "RadarSeries",
]

_CONTROL_ESCAPES = {
    0x00: "\\0",
    0x07: "\\a",
    0x08: "\\b",
    0x09: "\\t",
    0x0A: "\\n",
    0x0B: "\\v",
    0x0C: "\\f",
    0x0D: "\\r",
    0x1B: "\\e",
}

_HEX_NOISE = re.compile(r"0[xX]")
_HEX_SEPARATORS = re.compile(r"[\s,;:_\-]+")


def format_hex(data: bytes, sep: str = " ") -> str:
    """把字节串转成 `48 65 6C` 形式的大写 HEX 文本。"""
    return sep.join(f"{b:02X}" for b in data)


def format_ascii(data: bytes, escape_controls: bool = True) -> str:
    """把字节串转成可安全显示的文本。

    解码失败时用 ``backslashreplace``，无法解码的字节会显示成 ``\\xff`` 这种形式 ——
    既不会抛异常（旧版内核在示例回调里直接 ``data.decode('utf-8')``，一个干扰字节
    就会打死整个接收线程），也不会把原始字节信息丢掉。
    """
    text = data.decode("utf-8", errors="backslashreplace")
    if not escape_controls:
        return text
    out = []
    for ch in text:
        code = ord(ch)
        if code in _CONTROL_ESCAPES:
            out.append(_CONTROL_ESCAPES[code])
        elif code < 0x20 or code == 0x7F:
            out.append(f"\\x{code:02X}")
        else:
            out.append(ch)
    return "".join(out)


def parse_hex(text: str) -> bytes:
    """把用户输入的 HEX 文本解析成字节串。

    接受 `48 65 6C`、`48656C`、`0x48,0x65`、`48-65-6C` 等写法。
    """
    cleaned = _HEX_SEPARATORS.sub("", _HEX_NOISE.sub(" ", text))
    if not cleaned:
        return b""
    if len(cleaned) % 2:
        raise ValueError("HEX 内容的字符个数必须为偶数")
    try:
        return bytes.fromhex(cleaned)
    except ValueError as exc:
        raise ValueError(f"无法解析的 HEX 内容: {text!r}") from exc


class LineAssembler:
    """把不定长的字节流切成"显示行"。

    串口一次 read() 拿到的往往只是半行或者好几行，直接打印会出现断行。
    这里累积到换行符再切；如果长时间没有换行（例如设备只发二进制），
    超过 `max_gap` 秒也会切一刀，保证界面不会一直不刷新。
    """

    def __init__(self, max_gap: float = 0.08, max_len: int = 4096):
        self.max_gap = max_gap
        self.max_len = max_len
        self._buf = bytearray()
        self._started_at: float | None = None

    def feed(self, data: bytes, now: float | None = None) -> list[tuple[float, bytes]]:
        """喂入新数据，返回本次可以显示的行 [(首字节到达时刻, 该行字节), ...]。"""
        now = time.monotonic() if now is None else now
        if data:
            if not self._buf:
                self._started_at = now
            self._buf += data

        lines: list[tuple[float, bytes]] = []
        while self._buf:
            idx = self._buf.find(b"\n")
            if idx >= 0:
                chunk = bytes(self._buf[: idx + 1])
                del self._buf[: idx + 1]
                lines.append((self._started_at or now, chunk))
                self._started_at = now if self._buf else None
                continue
            if len(self._buf) >= self.max_len:
                chunk = bytes(self._buf)
                self._buf.clear()
                lines.append((self._started_at or now, chunk))
                self._started_at = None
                continue
            if self._started_at is not None and now - self._started_at >= self.max_gap:
                chunk = bytes(self._buf)
                self._buf.clear()
                lines.append((self._started_at, chunk))
                self._started_at = None
            break
        return lines

    def flush(self, now: float | None = None) -> list[tuple[float, bytes]]:
        """把还没成行的残留数据强制吐出来（关闭串口、清空窗口前调用）。"""
        now = time.monotonic() if now is None else now
        if not self._buf:
            return []
        chunk = bytes(self._buf)
        self._buf.clear()
        started = self._started_at or now
        self._started_at = None
        return [(started, chunk)]

    @property
    def pending(self) -> int:
        return len(self._buf)


_RADAR_RE = re.compile(
    r"^\$RADAR\s*,\s*(?P<seq>\d+)\s*,\s*(?P<range>-?\d+(?:\.\d+)?)\s*,"
    r"\s*(?P<vel>-?\d+(?:\.\d+)?)\s*,\s*(?P<snr>-?\d+(?:\.\d+)?)\s*$"
)


def parse_radar_frame(line: bytes | str) -> dict | None:
    """解析模拟遥测帧 `$RADAR,000123,128.40,-3.20,21.5`。

    不是遥测帧（例如 ACK 或普通文本）时返回 None，调用方据此忽略即可。
    """
    if isinstance(line, bytes):
        line = line.decode("utf-8", errors="replace")
    match = _RADAR_RE.match(line.strip())
    if match is None:
        return None
    return {
        "seq": int(match.group("seq")),
        "range": float(match.group("range")),
        "vel": float(match.group("vel")),
        "snr": float(match.group("snr")),
    }


class RadarSeries:
    """按顺序收集遥测帧，供绘图使用；容量固定，滚动覆盖。"""

    FIELDS = ("range", "vel", "snr")

    def __init__(self, capacity: int = 600):
        self.capacity = capacity
        self.seq: list[int] = []
        self.range: list[float] = []
        self.vel: list[float] = []
        self.snr: list[float] = []
        self.frames = 0
        self.gaps = 0
        self._last_seq: int | None = None

    def add(self, frame: dict) -> None:
        seq = frame["seq"]
        if self._last_seq is not None and seq > self._last_seq + 1:
            # 序号跳跃说明低波特率下缓冲区溢出丢了帧 —— 这正是对比实验要观察的现象
            self.gaps += seq - self._last_seq - 1
        self._last_seq = seq
        self.frames += 1
        self.seq.append(seq)
        self.range.append(frame["range"])
        self.vel.append(frame["vel"])
        self.snr.append(frame["snr"])
        if len(self.seq) > self.capacity:
            overflow = len(self.seq) - self.capacity
            del self.seq[:overflow]
            del self.range[:overflow]
            del self.vel[:overflow]
            del self.snr[:overflow]

    def series(self, field: str) -> list[float]:
        if field not in self.FIELDS:
            raise ValueError(f"未知字段: {field}")
        return list(getattr(self, field))

    def clear(self) -> None:
        for name in ("seq", "range", "vel", "snr"):
            getattr(self, name).clear()
        self.frames = 0
        self.gaps = 0
        self._last_seq = None
