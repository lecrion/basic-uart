"""串口枚举：把真实串口和内置虚拟串口统一成一份可选列表。

旧版把这段逻辑直接写在 ``serial_io_core.py`` 里并且只 ``print``，界面没法复用；
这里返回结构化的 ``PortInfo``，CLI 和 GUI 各取所需。
"""

from __future__ import annotations

import dataclasses

import serial.tools.list_ports

from .virtual import VIRTUAL_DEVICES, VIRTUAL_PREFIX

__all__ = [
    "PortInfo",
    "list_real_ports",
    "list_virtual_ports",
    "list_ports",
    "find_port",
    "format_table",
]


@dataclasses.dataclass(frozen=True)
class PortInfo:
    """一个可用端口的描述。"""

    device: str
    description: str
    hwid: str = ""
    vid: int | None = None
    pid: int | None = None
    serial_number: str | None = None
    manufacturer: str | None = None
    product: str | None = None
    is_virtual: bool = False

    @property
    def label(self) -> str:
        tag = " [虚拟]" if self.is_virtual else ""
        return f"{self.device}  {self.description}{tag}"

    def detail(self) -> str:
        if self.is_virtual:
            return "内置虚拟串口，不需要任何硬件"
        parts = [f"硬件ID: {self.hwid}"]
        if self.vid is not None:
            parts.append(f"VID:PID = {self.vid:04X}:{(self.pid or 0):04X}")
        if self.serial_number:
            parts.append(f"序列号: {self.serial_number}")
        if self.manufacturer:
            parts.append(f"厂商: {self.manufacturer}")
        return " | ".join(parts)


def list_real_ports(include_links: bool = False) -> list[PortInfo]:
    """枚举操作系统报告的真实串口。"""
    ports: list[PortInfo] = []
    for info in serial.tools.list_ports.comports(include_links=include_links):
        ports.append(
            PortInfo(
                device=info.device,
                description=info.description or "",
                hwid=info.hwid or "",
                vid=info.vid,
                pid=info.pid,
                serial_number=info.serial_number,
                manufacturer=info.manufacturer,
                product=info.product,
            )
        )
    return sorted(ports, key=lambda p: p.device)


def list_virtual_ports() -> list[PortInfo]:
    """列出内置虚拟设备，每个都可以直接用 ``SerialChannel`` 打开。"""
    return [
        PortInfo(
            device=f"{VIRTUAL_PREFIX}{name}",
            description=device_cls.description,
            hwid="VIRTUAL",
            manufacturer="uart_core",
            product=name,
            is_virtual=True,
        )
        for name, device_cls in sorted(VIRTUAL_DEVICES.items())
    ]


def list_ports(include_virtual: bool = True) -> list[PortInfo]:
    """真实串口 + 虚拟串口。虚拟口排在前面，方便无硬件时先看到。"""
    ports = list_virtual_ports() if include_virtual else []
    return ports + list_real_ports()


def find_port(device: str) -> PortInfo | None:
    for info in list_ports():
        if info.device.lower() == (device or "").lower():
            return info
    return None


def format_table(ports: list[PortInfo] | None = None) -> str:
    """把端口列表格式化成可打印的表格。"""
    ports = list_ports() if ports is None else ports
    if not ports:
        return "没有发现任何串口。"
    lines = [f"发现 {len(ports)} 个可用端口:", ""]
    for info in ports:
        lines.append(f"  {info.device}")
        lines.append(f"      说明: {info.description}")
        lines.append(f"      {info.detail()}")
    return "\n".join(lines)
