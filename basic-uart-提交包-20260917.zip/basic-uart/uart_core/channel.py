"""单个串口通道：收发、日志、回调分发、运行时改参数。

对应旧版 ``serial_io_core.SerialIO`` / ``SerialRecvThread``，修掉了下面这些问题：

===========================  ==========================================================
旧版问题                      本版做法
===========================  ==========================================================
``_serial_dict`` /            全部改成实例属性，多个通道互不干扰
``_trigger_list`` 是类属性
只认写死的 ``test_1``/``test_2``  tag 可自由命名，注册的回调全部会被调用
``_trigger_test_2`` 从不被调用
回调抛异常会打死接收线程        回调异常被捕获并上报，接收循环继续跑
``close()`` 不停止线程、无法退出  ``close()`` 会停线程、关端口、可重复调用
不记录发送方向                  收发双向都写带时间戳日志
无法在线改波特率                 ``reconfigure(baudrate=...)`` 在线生效
===========================  ==========================================================
"""

from __future__ import annotations

import logging
import threading
import time
from collections.abc import Callable

import serial

from .logbook import ChannelLog
from .virtual import is_virtual_port, open_virtual_transport

log = logging.getLogger(__name__)

__all__ = ["SerialChannel", "ChannelError", "DEFAULT_SETTINGS", "RECONFIGURABLE"]

#: 停顿式读取的超时（秒）。用短超时而不是 None，接收线程才能及时响应 close()。
DEFAULT_TIMEOUT = 0.05

DEFAULT_SETTINGS: dict[str, object] = {
    "baudrate": 115200,
    "bytesize": 8,
    "parity": "N",
    "stopbits": 1,
    "timeout": DEFAULT_TIMEOUT,
    "write_timeout": 1.0,
    "xonxoff": False,
    "rtscts": False,
    "dsrdtr": False,
}

#: 可以在打开状态下去的运行时参数
RECONFIGURABLE: tuple[str, ...] = tuple(DEFAULT_SETTINGS)


class ChannelError(RuntimeError):
    """串口操作失败。"""


def _name(func: Callable) -> str:
    return getattr(func, "__name__", None) or repr(func)


class SerialChannel:
    """一个串口通道。

    典型用法::

        with SerialChannel("VIRTUAL:ECHO", baudrate=115200, log_dir="log") as ch:
            ch.register_recv_trigger("display")(lambda data: print(data))
            ch.send(b"Hello")
    """

    def __init__(
        self,
        port: str,
        log_dir: str | None = None,
        transport=None,
        **settings,
    ):
        unknown = set(settings) - set(DEFAULT_SETTINGS)
        if unknown:
            raise ValueError(f"未知串口参数: {', '.join(sorted(unknown))}")

        self.port = port
        self._log_dir = log_dir
        self._settings: dict[str, object] = dict(DEFAULT_SETTINGS)
        self._settings.update(settings)

        self._lock = threading.RLock()
        self._callbacks: dict[str, list[Callable[[bytes], None]]] = {}
        self._filters: list[Callable[[bytes], bytes | None]] = []
        self._error_callbacks: list[Callable[[Exception, str], None]] = []
        self._state_callbacks: list[Callable[[bool, str], None]] = []

        self._transport = transport
        self._reader: threading.Thread | None = None
        self._stop = threading.Event()
        self._cyclic_thread: threading.Thread | None = None
        self._cyclic_stop: threading.Event | None = None
        self._log: ChannelLog | None = None

        self.bytes_rx = 0
        self.bytes_tx = 0
        self.chunks_rx = 0
        self.last_error: str | None = None
        self.opened_at: float | None = None

    # ------------------------------------------------------------------ 状态
    @property
    def is_open(self) -> bool:
        transport = self._transport
        return bool(transport is not None and getattr(transport, "is_open", False))

    @property
    def settings(self) -> dict:
        return dict(self._settings)

    @property
    def baudrate(self) -> int:
        return int(self._settings["baudrate"])

    @property
    def log_path(self) -> str | None:
        return self._log.path if self._log is not None else None

    @property
    def cyclic_active(self) -> bool:
        thread = self._cyclic_thread
        return bool(thread is not None and thread.is_alive())

    @property
    def callback_tags(self) -> list[str]:
        with self._lock:
            return sorted(self._callbacks)

    def describe(self) -> str:
        s = self._settings
        return f"{self.port} @ {s['baudrate']} / {s['bytesize']}{s['parity']}{s['stopbits']}"

    def snapshot(self) -> dict:
        """给界面用的一份状态快照（不暴露内部对象）。"""
        return {
            "port": self.port,
            "is_open": self.is_open,
            "baudrate": self._settings["baudrate"],
            "bytesize": self._settings["bytesize"],
            "parity": self._settings["parity"],
            "stopbits": self._settings["stopbits"],
            "bytes_rx": self.bytes_rx,
            "bytes_tx": self.bytes_tx,
            "chunks_rx": self.chunks_rx,
            "cyclic": self.cyclic_active,
            "last_error": self.last_error,
            "log_path": self.log_path,
            "tags": self.callback_tags,
        }

    # -------------------------------------------------------------- 生命周期
    def open(self) -> "SerialChannel":
        """打开串口并启动接收线程。重复调用是安全的。"""
        with self._lock:
            if self.is_open:
                return self
            transport = self._transport
            if transport is None:
                transport = self._create_transport()
            try:
                transport.open()
            except Exception as exc:
                self._transport = None
                raise ChannelError(f"打开 {self.port} 失败: {exc}") from exc

            self._transport = transport
            self._stop.clear()
            if self._log is None:
                self._log = ChannelLog(self._log_dir, self.port) if self._log_dir else None
            reader = threading.Thread(
                target=self._recv_loop, name=f"uart-rx-{self.port}", daemon=True
            )
            self._reader = reader
            reader.start()
        self.opened_at = time.monotonic()
        self._note_state(True, "已打开")
        return self

    def close(self, reason: str = "已关闭") -> None:
        """停止接收线程、关闭端口、收尾日志。可重复调用。"""
        self.stop_cyclic_send()
        with self._lock:
            reader, transport = self._reader, self._transport
            self._reader = None
            self._transport = None
            self._stop.set()

        if (
            reader is not None
            and reader.is_alive()
            and reader is not threading.current_thread()
        ):
            reader.join(timeout=2.0)
            if reader.is_alive():
                log.warning("%s 接收线程在 2 秒内没有退出", self.port)

        if transport is not None:
            try:
                transport.close()
            except Exception as exc:  # noqa: BLE001
                log.warning("关闭 %s 时出错: %s", self.port, exc)

        with self._lock:
            logbook, self._log = self._log, None
        if logbook is not None:
            logbook.note(f"本次会话 收 {self.bytes_rx}B / 发 {self.bytes_tx}B")
            logbook.close(reason)

        self.opened_at = None
        self._note_state(False, reason)

    def reconnect(self, **settings) -> "SerialChannel":
        self.close(reason="重连")
        if settings:
            self._settings.update(settings)
        return self.open()

    def _create_transport(self):
        if is_virtual_port(self.port):
            return open_virtual_transport(self.port, **self._settings)
        transport = serial.Serial()
        for key, value in self._settings.items():
            setattr(transport, key, value)
        transport.port = self.port
        return transport

    # ------------------------------------------------------------------ 收发
    def send(self, data: bytes | str) -> int:
        """发送数据，返回实际写入的字节数。"""
        if isinstance(data, str):
            data = data.encode("utf-8")
        data = bytes(data)
        with self._lock:
            transport = self._transport
            if transport is None or not getattr(transport, "is_open", False):
                raise ChannelError(f"串口 {self.port} 尚未打开")
            try:
                written = transport.write(data)
            except Exception as exc:
                raise ChannelError(f"向 {self.port} 写数据失败: {exc}") from exc
            try:
                transport.flush()
            except Exception as exc:  # noqa: BLE001
                log.debug("flush 失败: %s", exc)
        written = len(data) if written is None else written
        self.bytes_tx += written
        if self._log is not None:
            self._log.tx(data)
        return written

    def reconfigure(self, **params) -> dict:
        """在线修改串口参数（波特率/校验位/数据位/停止位/流控等），返回生效值。"""
        unknown = set(params) - set(RECONFIGURABLE)
        if unknown:
            raise ValueError(f"不可修改的参数: {', '.join(sorted(unknown))}")
        with self._lock:
            self._settings.update(params)
            transport = self._transport
            applied: dict[str, object] = {}
            if transport is not None:
                for key, value in params.items():
                    setattr(transport, key, value)
                    applied[key] = getattr(transport, key, value)
            else:
                applied = dict(params)
        if self._log is not None:
            self._log.note("参数变更: " + ", ".join(f"{k}={v}" for k, v in applied.items()))
        return applied

    # -------------------------------------------------------------- 循环发送
    def start_cyclic_send(self, payload: bytes | str, interval: float = 1.0) -> None:
        """按固定间隔循环发送。``interval`` 单位为秒。"""
        if interval <= 0:
            raise ValueError("循环发送间隔必须大于 0")
        if isinstance(payload, str):
            payload = payload.encode("utf-8")
        payload = bytes(payload)
        self.stop_cyclic_send()

        stop = threading.Event()

        def loop() -> None:
            next_at = time.monotonic()
            while not stop.is_set():
                try:
                    self.send(payload)
                except Exception as exc:  # noqa: BLE001
                    if not stop.is_set():
                        self._report_error(exc, "循环发送失败")
                    return
                next_at += interval
                delay = next_at - time.monotonic()
                if delay < 0:  # 落后了就重新对齐，避免越积越多
                    next_at = time.monotonic()
                    delay = 0.0
                if stop.wait(delay):
                    return

        thread = threading.Thread(target=loop, name=f"uart-cyclic-{self.port}", daemon=True)
        with self._lock:
            self._cyclic_stop = stop
            self._cyclic_thread = thread
        thread.start()

    def stop_cyclic_send(self) -> None:
        with self._lock:
            stop, thread = self._cyclic_stop, self._cyclic_thread
            self._cyclic_stop = None
            self._cyclic_thread = None
        if stop is not None:
            stop.set()
        if thread is not None and thread.is_alive() and thread is not threading.current_thread():
            thread.join(timeout=1.0)

    # ------------------------------------------------------------ 回调注册表
    def add_recv_callback(self, func: Callable[[bytes], None], tag: str = "default"):
        """注册接收回调，返回一个"取消注册"的函数。tag 可自由命名。"""
        if not callable(func):
            raise TypeError("接收回调必须可调用")
        with self._lock:
            self._callbacks.setdefault(tag, []).append(func)

        def remove() -> None:
            with self._lock:
                group = self._callbacks.get(tag)
                if group and func in group:
                    group.remove(func)
                    if not group:
                        self._callbacks.pop(tag, None)

        return remove

    def register_recv_trigger(self, tag: str = "default"):
        """装饰器写法，保留旧版习惯，但 tag 不再写死::

            @channel.register_recv_trigger("plot")
            def on_data(data: bytes) -> None: ...
        """

        def decorator(func):
            self.add_recv_callback(func, tag)
            return func

        return decorator

    def add_recv_filter(self, func: Callable[[bytes], bytes | None]):
        """注册接收过滤器：``func(data) -> bytes | None``，返回 None/空则丢弃这一批。"""
        if not callable(func):
            raise TypeError("过滤器必须可调用")
        with self._lock:
            self._filters.append(func)

        def remove() -> None:
            with self._lock:
                if func in self._filters:
                    self._filters.remove(func)

        return remove

    def add_error_callback(self, func: Callable[[Exception, str], None]):
        with self._lock:
            self._error_callbacks.append(func)
        return lambda: self._error_callbacks.remove(func) if func in self._error_callbacks else None

    def add_state_callback(self, func: Callable[[bool, str], None]):
        """注册连接状态回调：``func(is_open, reason)``。"""
        with self._lock:
            self._state_callbacks.append(func)
        return lambda: self._state_callbacks.remove(func) if func in self._state_callbacks else None

    def clear_recv_callbacks(self, tag: str | None = None) -> None:
        with self._lock:
            if tag is None:
                self._callbacks.clear()
            else:
                self._callbacks.pop(tag, None)

    # ------------------------------------------------------------ 接收主循环
    def _recv_loop(self) -> None:
        transport = self._transport
        while not self._stop.is_set():
            try:
                data = transport.read(1)
            except Exception as exc:  # noqa: BLE001 - 例如 USB 转串口被拔掉
                if not self._stop.is_set():
                    self._report_error(exc, "读取串口失败，接收线程已停止")
                    try:
                        self.close(reason="串口异常断开")
                    except Exception:  # noqa: BLE001
                        log.exception("异常断开后收尾失败")
                return

            if not data:
                continue

            waiting = getattr(transport, "in_waiting", 0) or 0
            if waiting:
                try:
                    data += transport.read(waiting)
                except Exception:  # noqa: BLE001 - 补齐失败就用已读到的部分
                    pass

            self.bytes_rx += len(data)
            self.chunks_rx += 1
            try:
                self._dispatch(data)
            except Exception:  # noqa: BLE001 - 兜底，绝不让接收线程死掉
                log.exception("分发接收数据时出现异常")

    def _dispatch(self, data: bytes) -> None:
        for func in list(self._filters):
            try:
                filtered = func(data)
            except Exception as exc:  # noqa: BLE001
                self._report_error(exc, f"接收过滤器 {_name(func)} 出错")
                continue
            if not filtered:
                return
            data = bytes(filtered)

        if self._log is not None:
            self._log.rx(data)

        for tag, funcs in list(self._callbacks.items()):
            for func in list(funcs):
                try:
                    func(data)
                except Exception as exc:  # noqa: BLE001 - 关键修复点
                    self._report_error(exc, f"接收回调 {_name(func)}（tag={tag}）出错")

    def _report_error(self, exc: Exception, context: str) -> None:
        self.last_error = f"{context}: {exc}"
        log.error("%s | %s: %s", self.port, context, exc)
        for func in list(self._error_callbacks):
            try:
                func(exc, context)
            except Exception:  # noqa: BLE001
                log.exception("错误回调自身出错")

    def _note_state(self, is_open: bool, reason: str) -> None:
        for func in list(self._state_callbacks):
            try:
                func(is_open, reason)
            except Exception:  # noqa: BLE001
                log.exception("状态回调自身出错")

    # ------------------------------------------------------------------ 杂项
    def __enter__(self) -> "SerialChannel":
        return self.open()

    def __exit__(self, *exc_info) -> None:
        self.close()

    def __repr__(self) -> str:  # pragma: no cover - 便于调试
        state = "open" if self.is_open else "closed"
        return f"<SerialChannel {self.port} {state} rx={self.bytes_rx} tx={self.bytes_tx}>"


def open_channel(port: str, log_dir: str | None = None, **settings) -> SerialChannel:
    """打开一个通道并返回它（等价于 ``SerialChannel(...).open()``）。"""
    return SerialChannel(port, log_dir=log_dir, **settings).open()
