"""修复 PyQt5 在「含非 ASCII 字符的路径」下无法启动的问题。

背景
----
Windows 上 Qt5 的平台插件加载器处理不了路径里的中文等非 ASCII 字符。
一旦项目被解压到 ``D:\\我的作业\\basic-uart`` 这种位置，创建 QApplication 时就会弹出::

    This application failed to start because no Qt platform plugin could be initialized.

然后进程直接以 0xC0000409 结束 —— 连 Python 异常都抓不到，所以从代码里看不出任何线索。

实测（同一份文件、同一个虚拟环境）：

===============================  ==========================
路径                              结果
===============================  ==========================
``...\\我的测试 目录\\...\\basic-uart``  崩溃
``...\\j_ascii\\...``（ASCII 联接）     正常
``...\\j with space\\...``（带空格）    正常
===============================  ==========================

可见**空格不是问题，非 ASCII 字符才是**。

规避办法
--------
把 Qt 的 ``platforms`` 插件复制到一个纯 ASCII 的目录，再用
``QT_QPA_PLATFORM_PLUGIN_PATH`` 指过去。插件总共约 5 MB，复制一次十几毫秒，
之后不再重复。路径本来就是 ASCII 时这个函数是空操作。
"""

from __future__ import annotations

import os
import shutil
import sys

__all__ = ["ensure_qt_plugin_path", "explain"]

#: 需要中转的插件类别（platforms 是启动必需的，其余影响外观和图片格式支持）
PLUGIN_SUBDIRS = ("platforms", "styles", "imageformats", "iconengines")

_TARGET_FOLDER = "uart-assistant-qtplugins"


def _plugin_source() -> str | None:
    """返回 PyQt5 自带的插件目录；取不到就返回 None。"""
    try:
        import PyQt5
    except Exception:  # noqa: BLE001 - 没装 PyQt5 就不需要处理
        return None
    base = os.path.dirname(os.path.abspath(PyQt5.__file__))
    candidate = os.path.join(base, "Qt5", "plugins")
    return candidate if os.path.isdir(candidate) else None


def _ascii_target() -> str:
    """挑一个纯 ASCII 的中转目录。

    优先系统盘根目录（与用户名无关，最不容易含中文），
    再退到 LOCALAPPDATA / TEMP / USERPROFILE，取第一个 ASCII 的。
    """
    candidates = [
        os.path.join(os.environ.get("SystemDrive", "C:") + os.sep, _TARGET_FOLDER),
        os.path.join(os.environ.get("LOCALAPPDATA", ""), _TARGET_FOLDER),
        os.path.join(os.environ.get("TEMP", ""), _TARGET_FOLDER),
        os.path.join(os.environ.get("USERPROFILE", ""), _TARGET_FOLDER),
    ]
    for path in candidates:
        if path and os.path.isabs(path) and path.isascii():
            return path
    # 全都不行就硬着头皮用系统盘（至少比中文路径强）
    return os.path.join(os.environ.get("SystemDrive", "C:") + os.sep, _TARGET_FOLDER)


def _copy_plugins(source: str, target: str) -> bool:
    """把插件复制过去；已经是最新就跳过。返回是否可用。"""
    copied = 0
    for subdir in PLUGIN_SUBDIRS:
        source_dir = os.path.join(source, subdir)
        if not os.path.isdir(source_dir):
            continue
        target_dir = os.path.join(target, subdir)
        try:
            os.makedirs(target_dir, exist_ok=True)
            for name in os.listdir(source_dir):
                source_file = os.path.join(source_dir, name)
                if not os.path.isfile(source_file):
                    continue
                target_file = os.path.join(target_dir, name)
                if os.path.exists(target_file):
                    old, new = os.stat(target_file), os.stat(source_file)
                    if old.st_size == new.st_size and old.st_mtime >= new.st_mtime:
                        continue
                shutil.copy2(source_file, target_file)
                copied += 1
        except OSError:
            return False
    # platforms 必须存在，否则中转没意义
    if not os.path.isdir(os.path.join(target, "platforms")):
        return False
    return True


def ensure_qt_plugin_path(verbose: bool = False) -> str | None:
    """必要时把 Qt 插件中转到一个 ASCII 目录。

    必须在 ``QApplication(...)`` 之前调用（在 ``import PyQt5`` 之后调用是可以的）。

    返回中转目录；返回 None 表示不需要处理或处理失败（调用方照常继续即可）。
    """
    if sys.platform != "win32":
        return None

    existing = os.environ.get("QT_QPA_PLATFORM_PLUGIN_PATH")
    if existing:
        return existing                      # 用户/环境已经指定了，尊重它

    source = _plugin_source()
    if source is None:
        return None
    if source.isascii():
        return None                          # 路径本来就是 ASCII，没有这个问题

    target = _ascii_target()
    if not _copy_plugins(source, target):
        if verbose:
            print(
                f"[qtplugin] PyQt5 位于非 ASCII 路径（{source}），"
                f"但插件中转失败。请把项目移动到纯英文路径后重试。",
                file=sys.stderr,
            )
        return None

    os.environ["QT_QPA_PLATFORM_PLUGIN_PATH"] = os.path.join(target, "platforms")
    os.environ.setdefault("QT_PLUGIN_PATH", target)
    if verbose:
        print(f"[qtplugin] PyQt5 位于非 ASCII 路径，已把 Qt 插件中转至 {target}")
    return target


def explain() -> str:
    """给界面/日志用的一句话说明。"""
    source = _plugin_source()
    if source is None:
        return "没有找到 PyQt5 的插件目录。"
    if source.isascii():
        return f"PyQt5 插件路径正常（{source}）。"
    target = os.environ.get("QT_QPA_PLATFORM_PLUGIN_PATH", "(未设置)")
    return f"PyQt5 位于非 ASCII 路径，Qt 插件已中转至 {target}。"
