"""uart_core —— 串口收发核心库。

把 pyserial 的底层收发封装成可复用的模块，向上提供三件事：

1. :class:`~uart_core.channel.SerialChannel` —— 单串口收发 + 回调 + 双向日志；
2. :class:`~uart_core.manager.ChannelManager` —— 同时管理多个串口；
3. :mod:`uart_core.virtual` —— 内置虚拟串口，没有硬件也能演示和自测。

典型用法::

    from uart_core import SerialChannel, parse_radar_frame

    with SerialChannel("VIRTUAL:RADAR", baudrate=115200, log_dir="log") as ch:
        ch.register_recv_trigger("plot")(lambda data: print(data))
        ch.send("RATE=10\\n")
"""

from .channel import ChannelError, DEFAULT_SETTINGS, RECONFIGURABLE, SerialChannel, open_channel
from .logbook import ChannelLog, save_text
from .manager import ChannelManager
from .ports import PortInfo, find_port, format_table, list_ports, list_real_ports, list_virtual_ports
from .protocols import (
    LineAssembler,
    RadarSeries,
    format_ascii,
    format_hex,
    parse_hex,
    parse_radar_frame,
)
from .virtual import (
    VIRTUAL_DEVICES,
    VIRTUAL_PREFIX,
    EchoDevice,
    RadarDevice,
    VirtualLink,
    VirtualSerial,
    is_virtual_port,
)

__version__ = "2.0.0"

__all__ = [
    "__version__",
    # 通道与管理
    "SerialChannel",
    "ChannelManager",
    "ChannelError",
    "open_channel",
    "DEFAULT_SETTINGS",
    "RECONFIGURABLE",
    # 枚举
    "PortInfo",
    "list_ports",
    "list_real_ports",
    "list_virtual_ports",
    "find_port",
    "format_table",
    # 日志
    "ChannelLog",
    "save_text",
    # 工具
    "LineAssembler",
    "RadarSeries",
    "format_hex",
    "format_ascii",
    "parse_hex",
    "parse_radar_frame",
    # 虚拟串口
    "VIRTUAL_PREFIX",
    "VIRTUAL_DEVICES",
    "is_virtual_port",
    "VirtualLink",
    "VirtualSerial",
    "EchoDevice",
    "RadarDevice",
]
