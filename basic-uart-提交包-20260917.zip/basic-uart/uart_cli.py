"""串口调试助手 —— 命令行版本。

既支持交互式收发，也支持"当成一个普通程序用 stdin/stdout 出入数据"的用法
（这是 README 技术设想里明确要求、旧版没有实现的那一条）：

    python uart_cli.py --list                                  # 列出所有端口
    python uart_cli.py -p VIRTUAL:RADAR                        # 交互式收发
    python uart_cli.py -p VIRTUAL:ECHO --send "Hello" --duration 2
    echo "HELLO" | python uart_cli.py -p VIRTUAL:RADAR --stdin # 管道式
    python uart_cli.py -p COM3 -r 9600 --hex --log-dir log
"""

from __future__ import annotations

import argparse
import datetime
import sys
import threading
import time

from uart_core import (
    ChannelError,
    ChannelManager,
    LineAssembler,
    format_ascii,
    format_hex,
    format_table,
    parse_hex,
)


def _force_utf8_stdout() -> None:
    """Windows 控制台默认是 GBK，直接 print 中文/非 ASCII 字节容易报错。

    输出重定向到文件时统一用 UTF-8；直接对着控制台时保留控制台编码，
    只把编码错误降级成替换字符，避免程序因为一个字节就崩掉。
    """
    for stream in (sys.stdout, sys.stderr):
        try:
            if stream.isatty():
                stream.reconfigure(errors="replace")
            else:
                stream.reconfigure(encoding="utf-8", errors="replace")
        except Exception:  # noqa: BLE001 - 不是所有流都支持
            pass


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="uart_cli",
        description="串口调试助手（命令行版）",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="示例:\n"
        "  python uart_cli.py --list\n"
        "  python uart_cli.py -p VIRTUAL:ECHO\n"
        "  python uart_cli.py -p VIRTUAL:RADAR --send HELLO --duration 3\n",
    )
    parser.add_argument("--list", "-l", action="store_true", help="只列出所有可用端口后退出")
    parser.add_argument("--port", "-p", default=None, help="端口名，例如 COM3 或 VIRTUAL:RADAR")
    parser.add_argument("--baudrate", "-r", type=int, default=115200, help="波特率，默认 115200")
    parser.add_argument("--bytesize", "-s", type=int, default=8, choices=[5, 6, 7, 8], help="数据位，默认 8")
    parser.add_argument("--parity", "-P", default="N", choices=["N", "E", "O", "M", "S"], help="校验位，默认 N")
    parser.add_argument("--stopbits", "-S", type=float, default=1, choices=[1, 1.5, 2], help="停止位，默认 1")
    parser.add_argument("--xonxoff", "-x", action="store_true", help="软件流控 XON/XOFF")
    parser.add_argument("--rtscts", "-c", action="store_true", help="硬件流控 RTS/CTS")
    parser.add_argument("--dsrdtr", "-d", action="store_true", help="硬件流控 DSR/DTR")
    parser.add_argument("--hex", action="store_true", help="以十六进制显示接收数据")
    parser.add_argument("--no-timestamp", action="store_true", help="接收时不打印时间戳")
    parser.add_argument("--send", action="append", default=[], help="打开后立即发送的内容，可重复")
    parser.add_argument("--send-hex", action="append", default=[], help="以 HEX 形式发送，可重复")
    parser.add_argument("--cyclic", type=float, default=None, metavar="SECONDS", help="循环发送 --send 内容，参数为间隔秒数")
    parser.add_argument("--stdin", action="store_true", help="从标准输入逐行读取并发送（管道模式）")
    parser.add_argument("--duration", type=float, default=None, metavar="SECONDS", help="运行指定秒数后自动退出")
    parser.add_argument("--log-dir", default="log", help="收发日志目录，默认 ./log，传空字符串关闭日志")
    parser.add_argument("--quiet-tx", action="store_true", help="不打印自己发出的内容")
    return parser


def main(argv: list[str] | None = None) -> int:
    _force_utf8_stdout()
    args = build_parser().parse_args(argv)

    if args.list or not args.port:
        print(format_table())
        if not args.port:
            print("\n提示: 用 --port 指定要打开的端口。")
        return 0

    settings = {
        "baudrate": args.baudrate,
        "bytesize": args.bytesize,
        "parity": args.parity,
        "stopbits": args.stopbits,
        "xonxoff": args.xonxoff,
        "rtscts": args.rtscts,
        "dsrdtr": args.dsrdtr,
    }
    manager = ChannelManager(log_dir=args.log_dir or None)
    try:
        channel = manager.open_channel(args.port, **settings)
    except ChannelError as exc:
        print(f"打开失败: {exc}", file=sys.stderr)
        print("\n可用端口:\n" + format_table(), file=sys.stderr)
        return 2

    print(f"已打开 {channel.describe()}")
    if channel.log_path:
        print(f"日志文件: {channel.log_path}")
    print("接收中… " + ("（HEX 模式）" if args.hex else "（文本模式）"))
    print("-" * 68)

    assembler = LineAssembler()
    printed = threading.Event()

    def show(data: bytes) -> None:
        for started, chunk in assembler.feed(data):
            stamp = datetime.datetime.now()
            prefix = "" if args.no_timestamp else f"[{stamp.strftime('%H:%M:%S.%f')[:-3]}] "
            body = format_hex(chunk) if args.hex else format_ascii(chunk).rstrip("\r\n")
            print(prefix + body)
            printed.set()

    detach = channel.add_recv_callback(show, tag="cli")

    def report_error(exc: Exception, context: str) -> None:
        print(f"!! {context}: {exc}", file=sys.stderr)

    channel.add_error_callback(report_error)

    # 先发 --send/--send-hex 指定的内容
    for text in args.send:
        channel.send(text + "\r\n")
        if not args.quiet_tx:
            print(f"-> {text}")
    for text in args.send_hex:
        payload = parse_hex(text)
        channel.send(payload)
        if not args.quiet_tx:
            print(f"-> {format_hex(payload)}")

    if args.cyclic is not None and args.send:
        channel.start_cyclic_send(args.send[0] + "\r\n", args.cyclic)
        print(f"循环发送中: {args.send[0]!r} 每 {args.cyclic} 秒")

    stop = threading.Event()

    def repl() -> None:
        """从 stdin 读一行就发一行；stdin 关闭（管道结束）时静默退出。"""
        for line in sys.stdin:
            if stop.is_set():
                return
            text = line.rstrip("\n")
            if text in (":q", ":quit", ":exit"):
                stop.set()
                return
            try:
                channel.send(text + "\r\n")
            except ChannelError as exc:
                print(f"发送失败: {exc}", file=sys.stderr)
                stop.set()
                return
            if not args.quiet_tx:
                print(f"-> {text}")

    reader = None
    if args.stdin or not sys.stdin.isatty():
        reader = threading.Thread(target=repl, name="uart-cli-stdin", daemon=True)
        reader.start()
    else:
        print("提示: 直接输入内容回车即发送，输入 :q 退出。")

    deadline = None if args.duration is None else time.monotonic() + args.duration
    try:
        while not stop.is_set():
            if deadline is not None and time.monotonic() >= deadline:
                break
            time.sleep(0.1)
    except KeyboardInterrupt:
        print("\n收到 Ctrl+C，正在退出…")

    for started, chunk in assembler.flush():
        body = format_hex(chunk) if args.hex else format_ascii(chunk).rstrip("\r\n")
        if body:
            print(body)

    stop.set()
    detach()
    snapshot = channel.snapshot()
    print("-" * 68)
    print(
        f"会话结束: 收 {snapshot['bytes_rx']} B / 发 {snapshot['bytes_tx']} B / "
        f"{snapshot['chunks_rx']} 批"
    )
    if channel.log_path:
        print(f"日志: {channel.log_path}")
    manager.close_all(reason="CLI 退出")
    return 0


if __name__ == "__main__":
    sys.exit(main())
